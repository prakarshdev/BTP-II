const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Broker = require("./broker-model");

const builderSchema = new mongoose.Schema({
  builderImage: {
    type: String,
  },
  name: {
    type: String,
    required: true,
  },
  reraNumber: {
    type: String,
    required: true,
    unique: true,
  },
  location: {
    type: String,
    required: true,
  },
  propertyType: {
    type: String,
    required: true,
  },
  contact: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
    minlength: 8,
  },
});

// Hash password before saving
builderSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  try {
    this.password = await this.hashPassword(this.password);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to hash password
builderSchema.methods.hashPassword = async function (password) {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

// Method to compare password
builderSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Generate JWT token
builderSchema.methods.generateAuthToken = function () {
  const token = jwt.sign(
    { _id: this._id, name: this.name, contact: this.contact },
    process.env.JWT_SECRET_KEY,
    { expiresIn: "7d" }
  );
  return token;
};

const Builder =
  mongoose.models.Builder || mongoose.model("Builder", builderSchema);

module.exports = Builder;
