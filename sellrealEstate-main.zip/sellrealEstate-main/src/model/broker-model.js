const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const Builder = require("./builder-model");

const brokerSchema = new mongoose.Schema({
  profilePicture: {
    type: String,
  },
  fullName: {
    type: String,
    required: true,
  },
  dateOfBirth: {
    type: Date,
    required: true,
  },
  phoneNumber: {
    type: String,
    required: true,
  },
  companyName: {
    type: String,
    required: true,
  },
  businessAddress: {
    type: String,
    required: true,
  },
  yearOfExperience: {
    type: Number,
    required: true,
  },
  reraRegistrationNumber: {
    type: String,
    required: true,
  },
  cities: {
    type: [String],
    required: true,
  },
  totalPropertiesSold: {
    type: Number,
    required: true,
  },
  pastDealClosures: {
    type: Number,
    required: true,
  },
  averageTimeToCloseDeal: {
    type: [String],
    required: true,
  },
  preferredPropertyType: {
    type: [String],
    required: true,
  },
  brokerageFeeStructure: {
    type: Number,
    required: true,
  },
  marketingPlatformUsed: {
    type: [String],
    required: true,
  },
  adsPlatformUsed: {
    type: [String],
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  aiRecommendations: {
    type: Boolean,
    required: true,
  },
  autoSuggestions: {
    type: Boolean,
    required: true,
  },
  aiGeneratedContent: {
    type: Boolean,
    required: true,
  },
});

brokerSchema.methods.generateAuthToken = function () {
  const token = jwt.sign(
    {
      _id: this._id,
      fullName: this.fullName,
      phoneNumber: this.phoneNumber,
      companyName: this.companyName,
      businessAddress: this.businessAddress,
      yearOfExperience: this.yearOfExperience,
      reraRegistrationNumber: this.reraRegistrationNumber,
      cities: this.cities,
    },
    process.env.JWT_SECRET_KEY,
    { expiresIn: "7d" }
  );
  return token;
};

// Hash password before saving
brokerSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  try {
    this.password = await this.hashPassword(this.password);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to hash password
brokerSchema.methods.hashPassword = async function (password) {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

// Method to compare password
brokerSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

const Broker = mongoose.models.Broker || mongoose.model("Broker", brokerSchema);

module.exports = Broker;
