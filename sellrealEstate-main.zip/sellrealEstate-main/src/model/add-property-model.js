const mongoose = require("mongoose");

const propertySchema = new mongoose.Schema(
  {
    builderId: {
      type: String,
      required: true,
    },
    projectName: {
      type: String,
      required: true,
    },
    typeOfProperty: {
      type: String,
      required: true,
    },
    configuration: {
      type: Number,
      required: true,
    },
    projectStatus: {
      type: String,
    },
    possessionDate: {
      type: Date,
      required: true,
    },
    launchDate: {
      type: Date,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    nearbyLandmarks: {
      type: String,
      required: true,
    },
    transportAccessibilityScore: {
      type: String,
      required: true,
    },
    builtUpArea: {
      type: Number,
      required: true,
    },
    carpetArea: {
      type: Number,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    maintenanceCharges: {
      type: Number,
      required: true,
    },
    expectedRentalYield: {
      type: Number,
      required: true,
    },
    brokerage: {
      type: Number,
      required: true,
    },
    paymentPlans: {
      type: String,
    },
    floorDetails: {
      type: String,
      required: true,
    },
    legalStatus: {
      type: String,
      required: true,
    },
    approvingAuthorities: {
      type: String,
      required: true,
    },
    numberOfBathrooms: {
      type: Number,
      required: true,
    },
    numberOfBalconies: {
      type: Number,
      required: true,
    },
    parkingAvailability: {
      type: String,
      required: true,
    },
    furnishingStatus: {
      type: String,
      required: true,
    },
    aiGeneratedCatalogue: {
      type: String,
      required: true,
    },
    mediaFiles: [{ type: String }],
    soldStatus: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

const Property =
  mongoose.models.Property || mongoose.model("Property", propertySchema);
module.exports = Property;
