import mongoose from "mongoose";
import jwt from "jsonwebtoken";

const userSchema = new mongoose.Schema({
  countryCode: {
    type: String,
    required: true,
  },
  mobileNumber: {
    type: Number,
    required: true,
    unique: true,
  },
});

userSchema.methods.generateAuthToken = function () {
  try {
    // Using toString() to ensure _id is properly serialized
    const payload = { _id: this._id.toString() };
    const token = jwt.sign(payload, process.env.JWT_SECRET_KEY || 'fallback-secret-key');
    return token;
  } catch (error) {
    throw error;
  }
};

const User = mongoose.models.User || mongoose.model("User", userSchema);

export default User;