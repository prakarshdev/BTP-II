const mongoose = require("mongoose");

const inquirySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  contact: {
    type: Number,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  area: {
    type: String,
    required: true,
  },
  searching: {
    type: [String],
    required: true,
  },
  brokerage: {
    type: String,
    required: true,
  },
  question: {
    type: String,
  },
});

const Inquiry =
  mongoose.models.Inquiry || mongoose.model("Inquiry", inquirySchema);

module.exports = Inquiry;
