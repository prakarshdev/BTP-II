import { z } from "zod";

export const userValidator = z.object({
  countryCode: z.string().min(1, { message: "Country code is required" }),
  mobileNumber: z
    .string()
    .regex(/^[6-9]\d{9}$/, { message: "Invalid mobile number" }),
});
