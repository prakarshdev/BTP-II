import { z } from "zod";

export const builderValidator = z.object({
  contact: z
    .string()
    .regex(/^[6-9]\d{9}$/, { message: "Invalid contact number" }),

  password: z.string().min(6, { message: "Password must be strong" }),
});
