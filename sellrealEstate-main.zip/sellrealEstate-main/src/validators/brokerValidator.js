// import { z } from "zod";

// // Minimal validator schema for just phoneNumber and password
// export const brokerPartialValidator = z.object({
//   phoneNumber: z.string().regex(/^[6-9]\d{9}$/, "Invalid phone number"),
//   password: z.string().min(6, "Password must be at least 6 characters"),
// });


import { z } from "zod";

export const brokerPartialValidator = z.object({
  phoneNumber: z
    .string()
    .regex(/^[6-9]\d{9}$/, { message: "Invalid phone number" }),

  password: z.string().min(6, { message: "Password must be strong" }), // You can add more checks if needed
});