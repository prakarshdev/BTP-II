import { create } from "zustand";

const useFilterStore = create((set) => ({
  priceRange: [100000, 100000000],
  selectedType: null,

  setPriceRange: (newRange) => set({ priceRange: newRange }),
  setSelectedType: (type) =>
    set((state) => ({
      selectedType: state.selectedType === type ? null : type,
    })),

  resetFilters: () =>
    set({ priceRange: [100000, 100000000], selectedType: null }),
}));

export default useFilterStore;
