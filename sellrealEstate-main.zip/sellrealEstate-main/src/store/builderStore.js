import { create } from "zustand";

const useBuilderStore = create((set) => ({
  builderData: null,
  builderToken: null,
  loading: true,

  setBuilderToken: (token) => set({ builderToken: token }),
  setBuilderData: (data) => set({ builderData: data, loading: false }),
  setLoading: (loading) => set({ loading }),

  fetchBuilderProfileData: async () => {
    const token = localStorage.getItem("builderToken");
    if (!token) {
      set({ loading: false });
      return;
    }
    set({ builderToken: token });

    try {
      const response = await fetch("/api/auth/builder-logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        set({ builderData: data.builderDetails, loading: false });
      } else {
        console.error("Error fetching builder data");
        set({ loading: false });
      }
    } catch (error) {
      console.error("Error in token API", error);
      set({ loading: false });
    }
  },

  logoutBuilder: () => {
    localStorage.removeItem("builderToken");
    localStorage.removeItem("builderId");
    localStorage.removeItem("builderName");
    set({ builderData: null, builderToken: null, loading: false });
  },
}));

export default useBuilderStore;
