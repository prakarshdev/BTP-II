"use client";

import React, { useEffect, useState } from "react";
import { ChevronLeft } from "lucide-react";
import { useRouter } from "next/navigation";
import Toggle from "./_components/Toggle";
import DropdownInput from "./_components/DropdownInput";
import PropertyTypeInput from "./_components/PropertyTypeInput";
import AverageTimeDeal from "./_components/AverageTimeDeal";
import MarketingPlatform from "./_components/MarketingPlatform";
import AddPlatforms from "./_components/AddPlatforms";
import toast, { Toaster } from "react-hot-toast";

const BrokerRegister = () => {
  const [step, setStep] = useState(1);
  const router = useRouter();

  const [profileImage, setProfileImage] = useState("");
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [businessAddress, setBusinessAddress] = useState("");
  const [experience, setExperience] = useState("");

  const [reraNumber, setReraNumber] = useState("");
  const [areaOfOperation, setAreaOfOperation] = useState("");
  const [totalPropertiesSold, setTotalPropertiesSold] = useState("");
  const [pastDealClosuresRate, setPastDealClosuresRate] = useState("");
  const [averageTimeToCloseDeal, setAverageTimeToCloseDeal] = useState("");
  const [preferredPropertyTypes, setPreferredPropertyTypes] = useState("");

  const [brokerageFeeStructure, setBrokerageFeeStructure] = useState("");
  const [marketingPlatformsUsed, setMarketingPlatformsUsed] = useState("");
  const [addPlatforms, setAddPlatforms] = useState("");
  const [password, setPassword] = useState("");
  const [aiRecommendations, setAiRecommendations] = useState(false);
  const [autoSuggestLeads, setAutoSuggestLeads] = useState(false);
  const [aiGeneratedMarketing, setAiGeneratedMarketing] = useState(false);

  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setProfileImage(file);
    toast.success("Profile image selected!");
  };

  const handleUpload = async () => {
    if (!profileImage) return "";

    const formData = new FormData();
    formData.append("file", profileImage);

    try {
      const res = await fetch("/api/upload-image", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        throw new Error("Upload failed");
      }

      const data = await res.json();
      console.log("image url: ", data.url);
      return data.url; // e.g., uploaded image URL from the server
    } catch (error) {
      console.error(error);
      toast.error("Image upload failed.");
      return "";
    }
  };

  const handleToggle = (type, data) => {
    switch (type) {
      case "ai":
        setAiRecommendations(() => data);
        break;
      case "leads":
        setAutoSuggestLeads(() => data);
        break;
      case "marketing":
        setAiGeneratedMarketing(() => data);
        break;
      default:
        break;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    // if (profileImage) {
    //   console.log("Uploaded File:", profileImage);
    // } else {
    //   console.log("No file uploaded.");
    // }

    try {
      const imageUrl = await handleUpload();
      const response = await fetch("/api/auth/broker-registration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          // profilePicture: profileImage,
          profilePicture: imageUrl,
          fullName: name,
          dateOfBirth: dob,
          phoneNumber: phone,
          companyName: company,
          businessAddress: businessAddress,
          yearOfExperience: experience,
          reraRegistrationNumber: reraNumber,
          cities: areaOfOperation,
          totalPropertiesSold: totalPropertiesSold,
          pastDealClosures: pastDealClosuresRate,
          averageTimeToCloseDeal: averageTimeToCloseDeal,
          preferredPropertyType: preferredPropertyTypes,
          brokerageFeeStructure: brokerageFeeStructure,
          marketingPlatformUsed: marketingPlatformsUsed,
          adsPlatformUsed: addPlatforms,
          password: password,
          aiRecommendations: aiRecommendations,
          autoSuggestions: autoSuggestLeads,
          aiGeneratedContent: aiGeneratedMarketing,
        }),
      });
      if (response.ok) {
        const data = await response.json();
        const brokerId = data.brokerId;
        const brokerToken = data.token;
        localStorage.setItem("brokerId", brokerId);
        localStorage.setItem("brokerToken", brokerToken);
        toast.success(data.message);
        router.push("/log-in/broker-login");
        setLoading(false);
      } else {
        const data = await response.json();
        toast.error(data.message);
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Something went wrong");
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  const handleAreaOfOperation = (data) => {
    setAreaOfOperation(data);
  };

  const handlePreferredPropertyTypes = (data) => {
    setPreferredPropertyTypes(data);
  };

  const handleAverageTimeToCloseDeal = (data) => {
    setAverageTimeToCloseDeal(data);
  };

  const handleMarketingPlatformsUsed = (data) => {
    setMarketingPlatformsUsed(data);
  };

  const handleAddPlatforms = (data) => {
    setAddPlatforms(data);
  };

  return (
    <div className="h-screen flex flex-col p-7 bg-white">
      <form onSubmit={handleSubmit}>
        {step === 1 && (
          <div>
            <div className="bg-black fixed top-2 left-7 w-1/4 h-1 rounded-2xl"></div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <ChevronLeft
                    className="w-7 h-7"
                    onClick={() => router.push("/sign-up/register")}
                  />
                  <h1 className="text-xl font-bold">Broker details</h1>
                </div>
                <div>
                  {profileImage ? (
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <img
                        src={URL.createObjectURL(profileImage)}
                        alt="Profile Preview"
                        className="w-14 h-14 rounded-full object-cover border-2 border-black"
                      />
                    </label>
                  ) : (
                    <label
                      htmlFor="file-upload"
                      className="bg-black text-white text-sm rounded-md px-3 py-2 cursor-pointer"
                    >
                      + Add profile photo
                    </label>
                  )}
                  <input
                    id="file-upload"
                    type="file"
                    name="profileImage"
                    accept=".jpg, .jpeg, .png"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Full Name
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Date of birth
                    </label>
                    <input
                      type="date"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter you DOB"
                      value={dob}
                      onChange={(e) => setDob(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Phone number
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter your phone number"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Company name
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter company name"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Business address
                    </label>
                    <textarea
                      className="bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter company name"
                      value={businessAddress}
                      onChange={(e) => setBusinessAddress(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Years of experience
                    </label>
                    <div className="relative flex items-center">
                      <input
                        type="number"
                        min="0"
                        className="h-10 bg-gray-100 rounded-md px-3 py-2 w-full"
                        placeholder="Years of experience"
                        value={experience}
                        onChange={(e) => setExperience(e.target.value)}
                      />
                      <div className="absolute right-2 flex flex-col">
                        <button
                          type="button"
                          onClick={() =>
                            setExperience((prev) => Number(prev) + 1)
                          }
                          className="text-gray-500 hover:text-gray-700 text-sm"
                        >
                          ▲
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setExperience((prev) =>
                              Math.max(0, Number(prev) - 1)
                            )
                          }
                          className="text-gray-500 hover:text-gray-700 text-sm"
                        >
                          ▼
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="fixed bottom-2 right-4 left-4 flex justify-end items-center mt-2.5">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <div className="bg-black fixed top-2 left-1/2 w-1/4 h-1 rounded-2xl text-center -translate-x-1/2"></div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <ChevronLeft className="w-7 h-7" onClick={() => setStep(1)} />
                  <h1 className="text-xl font-bold">Broker details</h1>
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      RERA Registration Number
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter RERA Registration Number"
                      value={reraNumber}
                      onChange={(e) => setReraNumber(e.target.value)}
                    />
                  </div>
                  <DropdownInput sendDataToParent={handleAreaOfOperation} />
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Total Properties Sold/Rented
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter total properties sold/rented"
                      value={totalPropertiesSold}
                      onChange={(e) => setTotalPropertiesSold(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Past Deal Closures Rate (%)
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter past deal closures rate"
                      value={pastDealClosuresRate}
                      onChange={(e) => setPastDealClosuresRate(e.target.value)}
                    />
                  </div>
                  <AverageTimeDeal
                    sendDataToParent={handleAverageTimeToCloseDeal}
                  />
                  <PropertyTypeInput
                    sendDataToParent={handlePreferredPropertyTypes}
                  />
                  <div className="flex justify-end items-center mt-8">
                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <div className="bg-black fixed top-2 right-7 w-1/4 h-1 rounded-2xl text-center"></div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <ChevronLeft className="w-7 h-7" onClick={() => setStep(2)} />
                  <h1 className="text-xl font-bold">Broker details</h1>
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Brokerage Fee Structure
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter brokerage fee structure"
                      value={brokerageFeeStructure}
                      onChange={(e) => setBrokerageFeeStructure(e.target.value)}
                    />
                  </div>
                  <MarketingPlatform
                    sendDataToParent={handleMarketingPlatformsUsed}
                  />
                  <AddPlatforms sendDataToParent={handleAddPlatforms} />
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      password
                    </label>
                    <input
                      type="password"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1 mt-2">
                    <div className="flex justify-between items-center">
                      <p className="text-base font-semibold">
                        Opt-in for AI Recommendations?
                      </p>
                      <Toggle
                        sendDataToParent={(data) => handleToggle("ai", data)}
                      />
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 mt-4">
                    <div className="flex justify-between items-center">
                      <p className="text-base font-semibold">
                        Allow Platform to Auto-Suggest Leads?
                      </p>
                      <Toggle
                        sendDataToParent={(data) => handleToggle("leads", data)}
                      />
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 mt-4">
                    <div className="flex justify-between items-center">
                      <p className="text-base font-semibold">
                        Enable AI-Generated Marketing Content?
                      </p>
                      <Toggle
                        sendDataToParent={(data) =>
                          handleToggle("marketing", data)
                        }
                      />
                    </div>
                  </div>

                  <div className="flex justify-end items-center mt-8 fixed bottom-5 left-7 right-7">
                    <button
                      type="submit"
                      className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full flex justify-center items-center gap-2"
                      disabled={loading}
                    >
                      {loading ? (
                        <>
                          <svg
                            className="w-5 h-5 animate-spin text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            />
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8v8z"
                            />
                          </svg>
                          Creating profile...
                        </>
                      ) : (
                        "Create profile"
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </form>
      <Toaster
        position="top-right"
        toastOptions={{
          success: {
            duration: 3000,
            iconTheme: {
              primary: "green",
              secondary: "black",
            },
          },
        }}
      />
    </div>
  );
};

export default BrokerRegister;
