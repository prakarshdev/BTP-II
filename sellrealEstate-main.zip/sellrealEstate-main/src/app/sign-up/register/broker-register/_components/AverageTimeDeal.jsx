"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

export default function AverageTimeDeal({ sendDataToParent }) {
  const [showOptions, setShowOptions] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const options = [
    "Less than 1 month",
    "1-2 months",
    "2-3 months",
    "3-4 months",
    "4-6 months",
    "6-8 months",
    "8-12 months",
    "More than 12 months"
  ];

  const handleSelect = (option, event) => {
    setInputValue(option);
    sendDataToParent(option);
    setTimeout(() => setShowOptions(false), 200);
  };

  return (
    <div className="flex flex-col gap-1 w-full">
      <label htmlFor="dropdown" className="text-base font-semibold">
        Average time to close a deal
      </label>
      <div className="relative">
        <div
          className="flex items-center h-10 bg-gray-100 rounded-md px-3 py-2 w-full cursor-pointer"
          onClick={() => setShowOptions(!showOptions)}
        >
          <input
            type="text"
            id="dropdown"
            value={inputValue}
            required
            placeholder="Select average time to close a deal"
            className="w-full bg-transparent outline-none cursor-pointer"
            readOnly
          />
          <button type="button">
            {showOptions ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
        </div>
        {showOptions && (
          <ul className="absolute left-0 right-0 bg-gray-100 rounded-lg shadow-md max-h-[120px] overflow-y-auto z-10">
            {options.map((option, index) => (
              <li
                key={index}
                onClick={(event) => handleSelect(option, event)}
                className="p-2 hover:bg-gray-200 cursor-pointer h-[40px] flex items-center"
              >
                {option}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
