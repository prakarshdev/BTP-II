"use client";

import { useState } from "react";

const Toggle = ({ sendDataToParent }) => {
  const [isOn, setIsOn] = useState(false);

  const handleToggle = () => {
    const newValue = !isOn;
    setIsOn(newValue);
    sendDataToParent(newValue);
  };

  return (
    <div
      className={`w-12 h-6 flex items-center bg-gray-300 rounded-full p-1 cursor-pointer transition-all flex-none ${
        isOn ? "bg-green-500" : "bg-gray-400"
      }`}
      onClick={handleToggle}
      style={{ minWidth: "48px", minHeight: "24px" }}
    >
      <div
        className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform flex-none ${
          isOn ? "translate-x-6" : "translate-x-0"
        }`}
        style={{ minWidth: "20px", minHeight: "20px" }}
      />
    </div>
  );
};

export default Toggle;
