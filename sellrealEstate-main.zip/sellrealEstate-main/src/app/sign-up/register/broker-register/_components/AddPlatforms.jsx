"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp, X } from "lucide-react";

export default function AddPlatforms({ sendDataToParent }) {
  const [showOptions, setShowOptions] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState([]);

  const options = [
    "Facebook",
    "WhatsApp",
    "Instagram",
    "LinkedIn",
    "Twitter",
  ];

  const handleSelect = (option) => {
    const newSelectedOptions = [...selectedOptions];
    
    if (newSelectedOptions.includes(option)) {
      // Remove the option if already selected
      const index = newSelectedOptions.indexOf(option);
      newSelectedOptions.splice(index, 1);
    } else {
      // Add the option if not already selected
      newSelectedOptions.push(option);
    }
    
    setSelectedOptions(newSelectedOptions);
    sendDataToParent(newSelectedOptions);
  };

  const removeOption = (option, e) => {
    e.stopPropagation();
    const newSelectedOptions = selectedOptions.filter(item => item !== option);
    setSelectedOptions(newSelectedOptions);
    sendDataToParent(newSelectedOptions);
  };

  return (
    <div className="flex flex-col gap-1 w-full">
      <label htmlFor="dropdown" className="text-base font-semibold">
        Ads Platforms
      </label>
      <div className="relative">
        <div
          className="flex items-center min-h-10 bg-gray-100 rounded-md px-3 py-2 w-full cursor-pointer"
          onClick={() => setShowOptions(!showOptions)}
        >
          <div className="flex flex-wrap gap-1 w-full">
            {selectedOptions.length > 0 ? (
              selectedOptions.map((option, index) => (
                <div key={index} className="bg-blue-100 px-2 py-1 rounded-md flex items-center text-sm">
                  {option}
                  <button type="button" onClick={(e) => removeOption(option, e)}>
                    <X size={16} className="ml-1" />
                  </button>
                </div>
              ))
            ) : (
              <span className="text-gray-500">Add platforms</span>
            )}
          </div>
          <button type="button">
            {showOptions ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
        </div>
        {showOptions && (
          <ul className="absolute left-0 right-0 bg-gray-100 rounded-lg shadow-md max-h-[200px] overflow-y-auto z-10">
            {options.map((option, index) => (
              <li
                key={index}
                onClick={() => handleSelect(option)}
                className={`p-2 hover:bg-gray-200 cursor-pointer ${
                  selectedOptions.includes(option) ? "bg-blue-100" : ""
                }`}
              >
                {option}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}