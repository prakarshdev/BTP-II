"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

export default function DropdownInput({ sendDataToParent }) {
  const [showOptions, setShowOptions] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const options = [
    "Delhi",
    "Mumbai",
    "Bangalore",
    "Hyderabad",
    "Chennai",
    "Kolkata",
    "Pune",
    "Ahmedabad",
    "Jaipur",
    "Surat",
    "Noida",
    "Gurgaon",
    "Thane",
    "Navi Mumbai",
    "Indore",
    "Other",
  ];

  const handleSelect = (option, event) => {
    setInputValue(option);
    sendDataToParent(option);
    setTimeout(() => setShowOptions(false), 200);
  };

  return (
    <div className="flex flex-col gap-1 w-full">
      <label htmlFor="dropdown" className="text-base font-semibold">
        Areas/Cities of operation
      </label>
      <div className="relative">
        <div
          className="flex items-center h-10 bg-gray-100 rounded-md px-3 py-2 w-full cursor-pointer"
          onClick={() => setShowOptions(!showOptions)}
        >
          <input
            type="text"
            id="dropdown"
            value={inputValue}
            required
            placeholder="Select areas/cities of operation"
            className="w-full bg-transparent outline-none cursor-pointer"
            readOnly
          />
          <button type="button">
            {showOptions ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
        </div>
        {showOptions && (
          <ul className="absolute left-0 right-0 bg-gray-100 rounded-lg shadow-md max-h-[200px] overflow-y-auto z-10">
            {options.map((option, index) => (
              <li
                key={index}
                onClick={(event) => handleSelect(option, event)}
                className="p-2 hover:bg-gray-200 cursor-pointer"
              >
                {option}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
