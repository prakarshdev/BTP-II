"use client";

import React, { useState } from "react";
import DropdownInput from "./_components/DropdownInput";
import Link from "next/link";
import { useRouter } from "next/navigation";
import toast, { Toaster } from "react-hot-toast";

const BuilderRegister = () => {
  const router = useRouter();

  const [formData, setFormData] = useState({
    builderImage: "",
    name: "",
    reraNumber: "",
    location: "",
    propertyType: "",
    contact: "",
    password: "",
  });

  const [imageFile, setImageFile] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setImageFile(file);
    toast.success("Image selected");
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePropertyType = (data) => {
    setFormData((prev) => ({
      ...prev,
      propertyType: data,
    }));
  };

  const uploadImage = async () => {
    if (!imageFile) return "";

    const imageForm = new FormData();
    imageForm.append("file", imageFile);

    try {
      const res = await fetch("/api/upload-image", {
        method: "POST",
        body: imageForm,
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Image upload failed");

      return data.url;
    } catch (error) {
      toast.error(error.message);
      return "";
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const imageUrl = await uploadImage();

    // if (!imageUrl) {
    //   setLoading(false);
    //   return;
    // }

    try {
      const response = await fetch("/api/auth/builder-registration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        // body: JSON.stringify(formData),
        body: JSON.stringify({ ...formData, builderImage: imageUrl }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Registration failed");
      }

      const builderId = data.builder.id;
      localStorage.setItem("builderId", builderId);
      toast.success("Registered successfully");
      setLoading(false);
      router.push("/log-in/builder-login");
    } catch (error) {
      // console.error("Registration error:", error);
      toast.error(error.message || "Registration failed");
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen flex flex-col gap-6 p-6">
      <form onSubmit={handleSubmit}>
        <div className="flex flex-col gap-3">
          <input
            id="file-upload"
            type="file"
            accept=".jpg, .jpeg, .png"
            className="hidden"
            onChange={handleFileChange}
          />

          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Builder details</h1>
            {imageFile ? (
              <img
                src={URL.createObjectURL(imageFile)}
                alt="Preview"
                className="h-16 w-16 object-cover rounded-full border"
              />
            ) : (
              <label
                htmlFor="file-upload"
                className="bg-black text-white text-sm rounded-md px-3 py-2 cursor-pointer"
              >
                + Add Photo
              </label>
            )}
          </div>

          <label className="text-base font-semibold -mb-1">Name</label>
          <input
            type="text"
            name="name"
            className="h-10 bg-gray-100 rounded-md px-3 py-2"
            required
            placeholder="Enter your name"
            value={formData.name}
            onChange={handleInputChange}
          />

          <label className="text-base font-semibold -mb-1">Rera number</label>
          <input
            type="text"
            name="reraNumber"
            className="h-10 bg-gray-100 rounded-md px-3 py-2"
            required
            placeholder="Enter rera number"
            value={formData.reraNumber}
            onChange={handleInputChange}
          />

          <label className="text-base font-semibold -mb-1">Location</label>
          <input
            type="text"
            name="location"
            className="h-10 bg-gray-100 rounded-md px-3 py-2"
            required
            placeholder="Enter your location"
            value={formData.location}
            onChange={handleInputChange}
          />

          <DropdownInput sendDataToParent={handlePropertyType} />

          <label className="text-base font-semibold -mb-1">
            Contact details
          </label>
          <input
            type="text"
            name="contact"
            className="h-10 bg-gray-100 rounded-md px-3 py-2"
            required
            placeholder="Enter contact details"
            value={formData.contact}
            onChange={handleInputChange}
          />

          <label className="text-base font-semibold -mb-1">Password</label>
          <input
            type="password"
            name="password"
            className="h-10 bg-gray-100 rounded-md px-3 py-2"
            required
            placeholder="Enter password"
            value={formData.password}
            onChange={handleInputChange}
          />

          <button
            type="submit"
            className="bg-black text-white font-bold px-4 py-2 rounded-lg mt-6 mb-4 w-full flex justify-center items-center gap-2"
            disabled={loading}
          >
            {loading ? (
              <>
                <svg
                  className="w-5 h-5 animate-spin"
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8v8z"
                  />
                </svg>
                Creating profile...
              </>
            ) : (
              "Create profile"
            )}
          </button>
        </div>
      </form>

      <Toaster position="top-right" />
    </div>
  );
};

export default BuilderRegister;
