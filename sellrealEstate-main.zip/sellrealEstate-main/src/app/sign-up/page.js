"use client";

import React, { useState } from "react";
import { FcGoogle } from "react-icons/fc";
import { FaApple } from "react-icons/fa";
import Link from "next/link";
import { useRouter } from "next/navigation";
import toast, { Toaster } from "react-hot-toast";
import { signIn } from "next-auth/react";

const SignUp = () => {
  const router = useRouter();

  const [mobNum, setMobNum] = useState("");
  const [countryCode, setCountryCode] = useState("+91");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      const response = await fetch("/api/auth/users", {
        method: "POST",
        body: JSON.stringify({
          countryCode: countryCode,
          mobileNumber: mobNum,
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setCountryCode("");
        setMobNum("");
        toast.success(data.message);
        setIsLoading(false);
        router.push("/sign-up/register");
      }
      if (!response.ok) {
        toast.error(data.message || "Something went wrong");
        setIsLoading(false);
        return;
      }
    } catch (error) {
      toast.error("Server error, Please try again");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* upper part */}
      <div
        className="w-full h-[50vh] bg-cover bg-center bg-no-repeat flex flex-col justify-center items-center"
        style={{ backgroundImage: "url('/assets/image.png')" }}
      >
        <div className="absolute inset-0 bg-black/60 backdrop-blur-base h-[50vh]"></div>
        <div className="relative z-10 flex flex-col justify-center items-center gap-[2vh] md:gap-[3vh] px-4 text-center">
          <img
            src="/assets/logo.png"
            alt="logo"
            className="w-[10vh] h-[9vh] md:w-[12vh] md:h-[10vh] lg:w-[14vh] lg:h-[12vh] object-cover"
          />
          <h1 className="text-white text-xl md:text-2xl lg:text-3xl font-bold">
            Sell property
          </h1>
          <p className="text-white text-sm md:text-lg lg:text-lg max-w-md">
            CLOSE YOUR DEALS WITHIN 10 DAYS
          </p>
          <p className="text-white text-sm md:text-lg lg:text-lg max-w-md">
            JOIN our Community.
          </p>
        </div>
      </div>

      {/* lower part */}
      <div className="bg-white rounded-t-3xl -mt-[2vh] relative h-[52vh] overflow-y-auto">
        <div className="px-4 sm:px-7 py-[4vh] max-w-xl mx-auto">
          <form onSubmit={handleSubmit} className="mb-[2vh]">
            <div className="flex flex-col gap-[2vh]">
              <p className="text-xl md:text-2xl font-bold">
                Enter your mobile number
              </p>
              <div className="flex justify-between items-center gap-2 md:gap-3">
                <input
                  className="w-1/6 h-10 bg-gray-100 rounded-md px-3 py-2"
                  type="text"
                  required
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value)}
                  placeholder="+91"
                />
                <input
                  className="w-5/6 h-10 bg-gray-100 rounded-md px-3 py-2"
                  type="number"
                  required
                  value={mobNum}
                  onChange={(e) => setMobNum(e.target.value)}
                  placeholder="Mobile number"
                />
              </div>
              <div className="flex justify-center items-center mt-[2vh]">
                <button
                  type="submit"
                  className="bg-black text-white text-center text-md font-bold px-4 py-[1.5vh] rounded-md w-full"
                >
                  {isLoading ? "Creating Account..." : "Create account"}
                </button>
              </div>
            </div>
          </form>
          <div className="flex flex-col gap-[2vh] mt-[3vh]">
            <p className="text-center text-gray-400 text-sm md:text-base">
              Or login with
            </p>
            <div className="flex justify-center items-center gap-[3vh]">
              <button
                className="shadow w-[7vh] h-[7vh] rounded-md flex justify-center items-center hover:shadow-md transition-shadow"
                onClick={() =>
                  signIn("google", { callbackUrl: "/sign-up/register" })
                }
              >
                <FcGoogle className="text-2xl md:text-3xl" />
              </button>
              <button className="shadow w-[7vh] h-[7vh] rounded-md flex justify-center items-center hover:shadow-md transition-shadow">
                <FaApple className="text-2xl md:text-3xl" />
              </button>
            </div>
          </div>
        </div>
      </div>
      <Toaster
        position="top-right"
        toastOptions={{
          success: {
            duration: 3000,
            iconTheme: {
              primary: "green",
              secondary: "black",
            },
          },
        }}
      />
    </div>
  );
};

export default SignUp;
