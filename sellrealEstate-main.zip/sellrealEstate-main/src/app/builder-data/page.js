"use client";
import { useState, useEffect } from "react";

export default function Builders() {
  const [builders, setBuilders] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // Fetch builders from API
  useEffect(() => {
    setLoading(true);
    fetch("/api/getbuilders")
      .then((res) => res.json())
      .then((data) => {
        setBuilders(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching builders:", error);
        setLoading(false);
      });
  }, []);

  const filteredBuilders = builders.filter(
    (builder) =>
      builder.location &&
      builder.location.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-6 text-center">Builders</h1>

      {/* Search Input */}
      <div className="flex justify-center mb-6">
        <input
          type="text"
          placeholder="Search by Location..."
          className="border p-2 w-full max-w-md rounded-lg shadow-sm outline-none focus:ring-2 focus:ring-blue-500"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Loading State */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : filteredBuilders.length === 0 ? (
        <div className="text-center text-gray-500 mt-10">
          <p>No builders found matching your search criteria.</p>
        </div>
      ) : (
        /* Builder List */
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {filteredBuilders.map((builder) => (
            <div
              key={builder._id}
              className="flex bg-white p-4 rounded-2xl shadow-lg hover:shadow-xl transition-all"
            >
              {/* Builder Image */}
              <img
                src={builder.builderImage || "/builder/image1.png"} // Use provided image or fallback
                alt={builder.name}
                className="w-40 h-40 object-cover rounded-lg flex-shrink-0"
              />

              {/* Builder Info */}
              <div className="ml-6 flex flex-col justify-center">
                <h2 className="text-xl font-semibold">{builder.name}</h2>
                <p className="text-gray-600">{builder.location}</p>
                <p className="text-gray-500 text-sm mt-1">
                  RERA: {builder.reraNumber}
                </p>
                <p className="text-gray-500 text-sm">
                  Contact: {builder.contact}
                </p>

                {/* Property Type Badge */}
                <div className="flex gap-2 mt-2 flex-wrap">
                  <span className="border border-gray-700 rounded-full px-4 py-1 text-sm text-gray-700">
                    {builder.propertyType}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
