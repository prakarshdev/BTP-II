"use client";

import React, { useState } from "react";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { useRouter } from "next/navigation";

const Register = () => {
  const [userType, setUserType] = useState(null);
  const router = useRouter();

  const handleSelection = (type) => {
    setUserType(type);

    // Redirect immediately based on selection
    if (type === "builder") {
      router.push("/log-in/builder-login");
    } else if (type === "broker") {
      router.push("/log-in/broker-login");
    }
  };

  // Initial selection screen
  return (
    <div className="min-h-screen flex flex-col gap-7 justify-center items-center p-8">
      <h1 className="text-2xl font-bold mb-12">Login as</h1>
      <button
        onClick={() => handleSelection("builder")}
        className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-md w-full"
      >
        Builder
      </button>
      <button
        onClick={() => handleSelection("broker")}
        className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-md w-full"
      >
        Broker
      </button>
      <div className="flex gap-16">
        <Link
          href="/sign-up/register"
          className="text-gray-500 text-md mt-2 underline"
        >
          Create new Account
        </Link>
      </div>
    </div>
  );
};

export default Register;
