"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import toast, { Toaster } from "react-hot-toast";
import { ChevronLeft } from "lucide-react";
import { set } from "zod";

const BuilderLogin = () => {
  const router = useRouter();

  const [formData, setFormData] = useState({
    contact: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);
      const response = await fetch("/api/auth/builder-login", {
        method: "POST",
        body: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        const data = await response.json();
        toast.success("Login successful");

        // Store builder ID in localStorage for authentication
        if (data.builder && data.builder._id) {
          localStorage.setItem("builderId", data.builder._id);
          localStorage.setItem("builderName", data.builder.name || "Builder");
          // Store the token if your app uses tokens for authentication
          if (data.token) {
            localStorage.setItem("builderToken", data.token);
          }
        }
        setLoading(false);

        router.push("/builder");
      } else {
        toast.error("Login failed. Please check your credentials.");
      }
    } catch (error) {
      toast.error("An error occurred while logging in.");
      console.log(error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen flex flex-col gap-6 p-6">
      <form onSubmit={handleSubmit}>
        <div className="flex items-center">
          <ChevronLeft
            className="w-7 h-7"
            onClick={() => router.push("/log-in")}
          />
          <h1 className="text-xl font-bold">Builder Login</h1>
        </div>
        <div className="flex flex-col gap-3 mt-6">
          <div className="flex flex-col gap-1">
            <label htmlFor="contact" className="text-base font-semibold">
              Contact details
            </label>
            <input
              type="text"
              name="contact"
              className="h-10 bg-gray-100 rounded-md px-3 py-2"
              placeholder="Enter contact details"
              required
              value={formData.contact}
              onChange={handleInputChange}
            />
          </div>
          <div className="flex flex-col gap-1">
            <label htmlFor="password" className="text-base font-semibold">
              Password
            </label>
            <input
              type="password"
              name="password"
              className="h-10 bg-gray-100 rounded-md px-3 py-2"
              placeholder="Enter password"
              required
              value={formData.password}
              onChange={handleInputChange}
            />
          </div>
          <div className="flex justify-end items-center mt-12">
            <button
              type="submit"
              className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full flex items-center justify-center"
              disabled={loading}
            >
              {loading ? (
                <span className="loader border-white w-5 h-5 border-2 border-t-transparent rounded-full animate-spin" />
              ) : (
                "Login"
              )}
            </button>
          </div>
        </div>
      </form>
      <Toaster
        position="top-right"
        toastOptions={{
          success: {
            duration: 3000,
            iconTheme: {
              primary: "green",
              secondary: "black",
            },
          },
        }}
      />
    </div>
  );
};

export default BuilderLogin;
