"use client";

import React, { useState } from "react";
import { ChevronLeft } from "lucide-react";
import { useRouter } from "next/navigation";
import toast, { Toaster } from "react-hot-toast";

const BrokerLogin = () => {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);
      const response = await fetch("/api/auth/broker-login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phoneNumber: phone,
          password: password,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const brokerToken = data.token;
        // Store broker Token in LocalStorage
        localStorage.setItem("brokerToken", brokerToken);
        // Store broker ID in localStorage
        if (data.broker && data.broker._id) {
          localStorage.setItem("brokerId", data.broker._id);
        } else {
          console.warn("Broker ID not found in response:", data);
        }

        toast.success(data.message);
        setLoading(false);
        router.push("/broker");
      } else {
        const data = await response.json();
        toast.error(data.message);
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen flex flex-col p-7">
      <form onSubmit={handleSubmit}>
        <div>
          {/* <div className="bg-black fixed top-2 left-7 w-1/4 h-1 rounded-2xl"></div> */}
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <ChevronLeft
                  className="w-7 h-7"
                  onClick={() => router.push("/log-in")}
                />
                <h1 className="text-xl font-bold">Broker Login</h1>
              </div>
            </div>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-base font-semibold">Phone Number</label>
                <input
                  type="number"
                  className="h-10 bg-gray-100 rounded-md px-3 py-2"
                  placeholder="Enter your phone number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-base font-semibold">Password</label>
                <input
                  type="password"
                  className="h-10 bg-gray-100 rounded-md px-3 py-2"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="flex justify-end items-center mt-5">
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full flex items-center justify-center"
                >
                  {loading ? (
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    "Login"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
      <Toaster
        position="top-right"
        toastOptions={{
          success: {
            duration: 3000,
            iconTheme: {
              primary: "green",
              secondary: "black",
            },
          },
        }}
      />
    </div>
  );
};

export default BrokerLogin;
