"use client";

import React, { useEffect, useState } from "react";
import { PlusCircle, Users, MessageCircle, Home } from "lucide-react";
import { useRouter } from "next/navigation";
import { FaUserCircle } from "react-icons/fa";
import Header from "./_components/Header";
import useBuilderStore from "../../store/builderStore";

const BuilderPage = () => {
  const router = useRouter();
  const [builder, setBuilder] = useState(true);

  // Zustand store state and actions
  const {
    builderData,
    builderToken,
    loading,
    setBuilderToken,
    fetchBuilderProfileData,
    logoutBuilder,
  } = useBuilderStore();

  useEffect(() => {
    const token = localStorage.getItem("builderToken");
    if (!token) {
      router.push("/log-in");
    } else {
      setBuilderToken(token);
      fetchBuilderProfileData();
      if (!builder && !builderData) {
        router.push("/log-in");
      }
    }
  }, [router, setBuilderToken, fetchBuilderProfileData]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="w-8 h-8 border-4 border-gray-200 border-t-gray-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col text-black">
      {/* Top Bar */}
      <Header />

      {/* Dashboard Header */}
      <div className="mx-4 mt-6 border-2 rounded-lg bg-gradient-to-r from-gray-900 to-gray-700 text-white py-3 text-center font-bold text-xl shadow-lg uppercase tracking-widest">
        Builder Dashboard
      </div>

      {/* Page Info */}
      <div className="max-w-md mx-auto mt-8 text-center px-6">
        <p className="text-gray-400 text-lg font-medium">
          Manage your properties and broker connections seamlessly from one
          place.
        </p>
      </div>

      {/* Dashboard Buttons */}
      <div className="max-w-2xl mx-auto mt-8 flex-1 flex items-center">
        <div className="grid grid-cols-2 gap-6 w-full">
          {[
            {
              label: "Add Property",
              icon: <PlusCircle size={30} />,
              path: "/builder/add-property",
            },
            {
              label: "Broker List",
              icon: <Users size={30} />,
              path: "/broker-data",
            },
            {
              label: "Inquiry",
              icon: <MessageCircle size={30} />,
              path: "/builder/inquiry",
            },
            {
              label: "Property List",
              icon: <Home size={30} />,
              path: "/builder/builderProperty",
            },
          ].map((item, index) => (
            <button
              key={index}
              className="group flex flex-col items-center justify-center bg-gray-300 text-black p-6 rounded-xl border border-gray-600 hover:bg-gray-700 hover:shadow-xl transition-all duration-300 h-36"
              onClick={() => router.push(item.path)}
            >
              <div className="p-3 rounded-full bg-white group-hover:bg-gray-600 transition-colors duration-300 mb-3">
                {item.icon}
              </div>
              <span className="text-lg font-semibold">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BuilderPage;
