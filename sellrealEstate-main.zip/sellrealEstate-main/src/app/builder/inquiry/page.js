"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import BrokerRequestCard from "./_component/BrokerRequestCard";

const BrokerRequests = () => {
  const router = useRouter();

  const [brokerRequests, setBrokerRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // authorization step
  const [builderToken, setBuilderToken] = useState(null);
  const [builderId, setBuilderId] = useState(null);
  useEffect(() => {
    const builderToken = localStorage.getItem("builderToken");
    if (!builderToken) {
      router.push("/log-in");
    }
    setBuilderToken(builderToken);
  }, []);

  useEffect(() => {
    if (!builderToken) {
      return;
    }
    const fetchBuilderData = async () => {
      try {
        const response = await fetch("/api/auth/builder-logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${builderToken}`,
          },
        });
        if (!response.ok) {
          console.log("builder is not authorized");
          router.push("/log-in");
        }
        const data = await response.json();
        const builderId = data.builderDetails._id;
        setBuilderId(builderId);
      } catch (error) {
        console.error("printing authorization error", error);
      }
    };
    fetchBuilderData();
  }, [builderToken]);

  const handleAccept = async (id) => {
    try {
      const response = await fetch(`/api/connection-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "accepted" }),
      });

      const data = await response.json();
      if (data.success) {
        setBrokerRequests((prev) =>
          prev.map((broker) =>
            broker._id === id ? { ...broker, status: "accepted" } : broker
          )
        );
      }
    } catch (error) {
      console.error("Error accepting request:", error);
    }
  };

  // getting all requests
  useEffect(() => {
    if (!builderId) {
      return;
    }
    const fetchAllrequests = async () => {
      try {
        const response = await fetch(`/api/getAllrequests/${builderId}`);
        if (!response.ok) {
          console.log("not getting respons");
        }
        const data = await response.json();
        setBrokerRequests(data);
        setLoading(false);
      } catch (error) {
        console.error("error in getting requests", error);
        setLoading(false);
      }
    };
    fetchAllrequests();
  }, [builderId]);

  const handleReject = async (id) => {
    try {
      const response = await fetch(`/api/connection-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "rejected" }),
      });

      const data = await response.json();
      if (data.success) {
        setBrokerRequests((prev) => prev.filter((broker) => broker._id !== id));
      }
    } catch (error) {
      console.error("Error rejecting request:", error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="w-8 h-8 border-4 border-gray-200 border-t-gray-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="p-4 bg-gray-100 min-h-screen">
      <div className="flex w-full bg-white items-center gap-4 mb-3.5 z-20 fixed top-0 left-0 right-0 p-4 shadow-md">
        <ArrowLeft
          size={28}
          className="cursor-pointer hover:text-gray-700"
          onClick={() => router.back()}
        />
        <h1 className="text-2xl font-bold">Broker Requests</h1>
      </div>

      {/* Broker Cards or Empty Message */}
      <div className="space-y-4 mt-16">
        {brokerRequests.length > 0 ? (
          brokerRequests.map((broker) => (
            <BrokerRequestCard
              key={broker?._id}
              broker={broker}
              onAccept={handleAccept}
              onReject={handleReject}
            />
          ))
        ) : (
          <div className="text-center text-gray-600 mt-20 text-lg font-semibold">
            No inquiries found.
          </div>
        )}
      </div>
    </div>
  );
};

export default BrokerRequests;
