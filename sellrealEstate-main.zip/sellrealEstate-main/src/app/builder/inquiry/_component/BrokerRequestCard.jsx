"use client";

import React from "react";

const BrokerRequestCard = ({ broker, onAccept, onReject }) => {
  return (
    <div className="bg-white shadow-md rounded-xl p-4 flex items-center space-x-4 w-full">
      <img
        src={broker?.brokerId?.profilePicture}
        alt={broker?.brokerId?.fullName}
        className="w-20 h-20 rounded-full border"
      />
      <div className="flex-1">
        <h2 className="text-lg font-semibold">{broker?.brokerId?.fullName}</h2>
        <p className="text-sm text-gray-500">
          {broker?.brokerId?.businessAddress}
        </p>
        <p className="text-sm">
          <span className="font-semibold">Company:</span>{" "}
          {broker?.brokerId?.companyName}
        </p>
        <p className="text-sm">
          <span className="font-semibold">Phone:</span>{" "}
          {broker?.brokerId?.phoneNumber}
        </p>
        <p className="text-sm">
          <span className="font-semibold">Status:</span>{" "}
          <span
            className={
              broker.status === "pending"
                ? "text-yellow-500"
                : broker.status === "accepted"
                ? "text-green-500"
                : "text-red-500"
            }
          >
            {broker.status}
          </span>
        </p>
        <div className="flex justify-between text-blue-500 text-sm mt-2">
          <a
            href={`/broker-data/${broker?.brokerId?._id}`}
            className="underline"
          >
            Broker Profile
          </a>
          <a
            href={`/builder/builderProperty/${broker?.propertyId?._id}`}
            className="underline"
          >
            View Property
          </a>
        </div>
        <div className="flex space-x-4 mt-2">
          <button
            onClick={() => onAccept(broker?._id)}
            className="px-3 py-1 bg-green-500 text-white rounded-md text-sm"
          >
            Accept
          </button>
          <button
            onClick={() => onReject(broker?._id)}
            className="px-3 py-1 bg-red-500 text-white rounded-md text-sm"
          >
            Reject
          </button>
        </div>
      </div>
    </div>
  );
};

export default BrokerRequestCard;
