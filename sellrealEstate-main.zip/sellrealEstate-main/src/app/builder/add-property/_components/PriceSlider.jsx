"use client";
import { useState, useEffect, memo } from "react";

const PriceSlider = memo(({ onPriceChange }) => {
  const minPrice = 10000;
  const maxPrice = 10000000;
  const [price, setPrice] = useState(minPrice);

  useEffect(() => {
    onPriceChange(price);
  }, [price, onPriceChange]);

  const handleChange = (e) => {
    setPrice(Number(e.target.value));
  };

  return (
    <div className="w-full max-w-md">
      {/* Label and Price on the Same Line */}
      <div className="flex justify-between items-center mb-1">
        <label className="font-semibold text-gray-800">
          Price (per sq. ft.)
        </label>
        <span className="text-gray-700 text-sm font-medium bg-white px-3 py-1 rounded-md shadow">
          ₹ {price.toLocaleString()}
        </span>
      </div>

      {/* Slider */}
      <div className="relative w-full">
        <input
          type="range"
          min={minPrice}
          max={maxPrice}
          value={price}
          onChange={handleChange}
          className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-gray-600 
                     [&::-webkit-slider-thumb]:appearance-none 
                     [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:h-6 
                     [&::-webkit-slider-thumb]:bg-gray-600 [&::-webkit-slider-thumb]:rounded-full 
                     [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white 
                     [&::-webkit-slider-thumb]:shadow-md"
        />
      </div>
    </div>
  );
});

PriceSlider.displayName = "PriceSlider";

export default PriceSlider;
