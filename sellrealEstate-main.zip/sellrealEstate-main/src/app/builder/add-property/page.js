"use client";

import React, { useState, useCallback, useEffect } from "react";
import { ChevronLeft } from "lucide-react";
import { useRouter } from "next/navigation";
import PriceSlider from "./_components/PriceSlider";
import toast, { Toaster } from "react-hot-toast";
import useBuilderStore from "../../../store/builderStore";

function convertToBase64(file) {
  return new Promise((resolve, reject) => {
    const fileReader = new FileReader();
    fileReader.readAsDataURL(file);
    fileReader.onload = () => {
      resolve(fileReader.result);
    };
    fileReader.onerror = (error) => reject(error);
  });
}

const AddProperty = () => {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [selectedFiles, setSelectedFiles] = useState([]);

  const [addPropertyData, setAddPropertyData] = useState({
    builderId: "",
    projectName: "",
    typeOfProperty: "",
    configuration: 0,
    projectStatus: "",
    possessionDate: "",
    launchDate: "",
    address: "",
    nearbyLandmarks: "",
    transportAccessibilityScore: "",
    builtUpArea: 0,
    carpetArea: 0,
    price: 0,
    maintenanceCharges: 0,
    expectedRentalYield: 0,
    brokerage: 0,
    paymentPlans: "",
    floorDetails: "",
    legalStatus: "",
    approvingAuthorities: "",
    numberOfBathrooms: 0,
    numberOfBalconies: 0,
    parkingAvailability: "",
    furnishingStatus: "",
    aiGeneratedCatalogue: "",
    mediaFiles: [],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAddPropertyData({ ...addPropertyData, [name]: value });
  };

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    setSelectedFiles((prevFiles) => [...prevFiles, ...files]);
    // Convert each file to base64
    const base64Files = await Promise.all(
      files.map(async (file) => {
        const base64 = await convertToBase64(file);
        toast.success(`File ${file.name} uploaded successfully`);
        return base64;
      })
    );

    setAddPropertyData((prev) => ({
      ...prev,
      mediaFiles: [...prev.mediaFiles, ...base64Files],
    }));
  };

  const handlePriceChange = useCallback((price) => {
    setAddPropertyData((prev) => ({
      ...prev,
      price: price,
    }));
  }, []);

  //? authorization step
  // Zustand store state and actions
  const {
    builderData,
    builderToken,
    // loading,
    setBuilderToken,
    fetchBuilderProfileData,
    logoutBuilder,
  } = useBuilderStore();

  useEffect(() => {
    const token = localStorage.getItem("builderToken");
    if (!token) {
      router.push("/log-in");
    } else {
      setBuilderToken(token);
      fetchBuilderProfileData();
    }
  }, [router, setBuilderToken, fetchBuilderProfileData]);

  // set  builderId from the local storage
  // const builderId = localStorage.getItem("builderId");
  // addPropertyData.builderId = builderId;
  useEffect(() => {
    const id = localStorage.getItem("builderId");
    if (id) {
      setAddPropertyData((prev) => ({
        ...prev,
        builderId: id,
      }));
    }
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("/api/addproperty", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(addPropertyData),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success("Property added successfully");
        router.push("/builder");
      } else {
        toast.error(data.message || "Failed to add property");
      }
    } catch (error) {
      toast.error("Failed to add property");
      console.error("Error:", error);
    }
  };

  return (
    <div className="h-screen flex flex-col p-7">
      <form onSubmit={handleSubmit}>
        <div className="fixed top-2 left-7 right-7 grid grid-cols-4 gap-2">
          <div
            className={`h-1 rounded-2xl ${
              step >= 1 ? "bg-black" : "bg-gray-200"
            }`}
          ></div>
          <div
            className={`h-1 rounded-2xl ${
              step >= 2 ? "bg-black" : "bg-gray-200"
            }`}
          ></div>
          <div
            className={`h-1 rounded-2xl ${
              step >= 3 ? "bg-black" : "bg-gray-200"
            }`}
          ></div>
          <div
            className={`h-1 rounded-2xl ${
              step >= 4 ? "bg-black" : "bg-gray-200"
            }`}
          ></div>
        </div>
        {step === 1 && (
          <div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <ChevronLeft
                    className="w-7 h-7"
                    onClick={() => router.push("/builder")}
                  />
                  <h1 className="text-xl font-bold">Add Property</h1>
                </div>
                <div>
                  <label
                    htmlFor="file-upload"
                    className="bg-black text-white text-base font-semibold rounded-md px-3 py-2 cursor-pointer"
                  >
                    + Upload media
                  </label>
                  <input
                    id="file-upload"
                    type="file"
                    className="hidden"
                    multiple
                    onChange={handleFileChange}
                  />
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Project Name
                    </label>
                    <input
                      type="text"
                      name="projectName"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter project name"
                      value={addPropertyData.projectName}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Type of Property
                    </label>
                    <input
                      type="text"
                      name="typeOfProperty"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter type of property"
                      value={addPropertyData.typeOfProperty}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Configuration (For residential properties)
                    </label>
                    <input
                      type="number"
                      name="configuration"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter configuration"
                      value={addPropertyData.configuration}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Project Status
                    </label>
                    <textarea
                      className="h-20 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter project status"
                      name="projectStatus"
                      value={addPropertyData.projectStatus}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Possession Date
                    </label>
                    <input
                      type="date"
                      className="bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter possession date"
                      name="possessionDate"
                      value={addPropertyData.possessionDate}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Launch Date
                    </label>
                    <div className="relative flex items-center">
                      <input
                        type="date"
                        className="h-10 bg-gray-100 rounded-md px-3 py-2 w-full"
                        placeholder="Enter launch date"
                        name="launchDate"
                        value={addPropertyData.launchDate}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end items-center mt-2.5">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <ChevronLeft className="w-7 h-7" onClick={() => setStep(1)} />
                  <h1 className="text-xl font-bold">Add Property</h1>
                </div>
                <div>
                  <label
                    htmlFor="file-upload"
                    className="bg-black text-white text-base font-semibold rounded-md px-3 py-2 cursor-pointer"
                  >
                    + Upload media
                  </label>
                  <input
                    id="file-upload"
                    type="file"
                    className="hidden"
                    multiple
                    onChange={handleFileChange}
                  />
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Complete Address
                    </label>
                    <textarea
                      className="h-20 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter complete address"
                      name="address"
                      value={addPropertyData.address}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Nearby landmarks
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter nearby landmarks"
                      name="nearbyLandmarks"
                      value={addPropertyData.nearbyLandmarks}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Transport & Accessibility Score
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter transport & accessibility score"
                      name="transportAccessibilityScore"
                      value={addPropertyData.transportAccessibilityScore}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Built-up Area (sq.ft)
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter built-up area"
                      name="builtUpArea"
                      value={addPropertyData.builtUpArea}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Carpet Area (sq.ft)
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter carpet area"
                      name="carpetArea"
                      value={addPropertyData.carpetArea}
                      onChange={handleChange}
                    />
                  </div>
                  <PriceSlider onPriceChange={handlePriceChange} />
                  <div className="flex justify-end items-center mt-4">
                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <ChevronLeft className="w-7 h-7" onClick={() => setStep(2)} />
                  <h1 className="text-xl font-bold">Add property</h1>
                </div>
                <div>
                  <label
                    htmlFor="file-upload"
                    className="bg-black text-white text-base font-semibold rounded-md px-3 py-2 cursor-pointer"
                  >
                    + Upload media
                  </label>
                  <input
                    id="file-upload"
                    type="file"
                    className="hidden"
                    multiple
                    onChange={handleFileChange}
                  />
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Maintenance Charges (if applicable)
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter maintenance charges"
                      name="maintenanceCharges"
                      value={addPropertyData.maintenanceCharges}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Expected Rental Yield
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter expected rental yield"
                      name="expectedRentalYield"
                      value={addPropertyData.expectedRentalYield}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Brokerage (%)
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter expected rental yield"
                      name="brokerage"
                      value={addPropertyData.brokerage}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Payment Plans & Installments
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter payment plans & installments"
                      name="paymentPlans"
                      value={addPropertyData.paymentPlans}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Floor Number & Total Floors
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter floor number & total floors"
                      name="floorDetails"
                      value={addPropertyData.floorDetails}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Legal Status (Titile Dead, NOCs, Approvals)
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter legal status"
                      name="legalStatus"
                      value={addPropertyData.legalStatus}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex justify-end items-center mt-8 fixed bottom-5 left-7 right-7">
                    <button
                      type="button"
                      onClick={() => setStep(4)}
                      className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <ChevronLeft className="w-7 h-7" onClick={() => setStep(3)} />
                  <h1 className="text-xl font-bold">Add property</h1>
                </div>
                <div>
                  <label
                    htmlFor="file-upload"
                    className="bg-black text-white text-base font-semibold rounded-md px-3 py-2 cursor-pointer"
                  >
                    + Upload media
                  </label>
                  <input
                    id="file-upload"
                    type="file"
                    className="hidden"
                    multiple
                    onChange={handleFileChange}
                  />
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      List of Approving Authorities
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter list of approving authorities"
                      name="approvingAuthorities"
                      value={addPropertyData.approvingAuthorities}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Number of Bathrooms
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter number of bathrooms"
                      name="numberOfBathrooms"
                      value={addPropertyData.numberOfBathrooms}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Balconies
                    </label>
                    <input
                      type="number"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter number of balconies"
                      name="numberOfBalconies"
                      value={addPropertyData.numberOfBalconies}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Parking availability
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter parking available"
                      name="parkingAvailability"
                      value={addPropertyData.parkingAvailability}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      Furnishing Status
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter furnishing status"
                      name="furnishingStatus"
                      value={addPropertyData.furnishingStatus}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex flex-col flex-grow gap-1">
                    <label htmlFor="name" className="text-base font-semibold">
                      AI generated catalogue
                    </label>
                    <input
                      type="text"
                      className="h-10 bg-gray-100 rounded-md px-3 py-2"
                      placeholder="Enter AI generated catalogue"
                      name="aiGeneratedCatalogue"
                      value={addPropertyData.aiGeneratedCatalogue}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="flex justify-end items-center mt-8 fixed bottom-5 left-7 right-7">
                    <button
                      type="submit"
                      className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-lg w-full"
                    >
                      Add property
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </form>
      <Toaster
        position="top-right"
        toastOptions={{
          success: {
            duration: 3000,
            iconTheme: {
              primary: "green",
              secondary: "black",
            },
          },
        }}
      />
    </div>
  );
};

export default AddProperty;
