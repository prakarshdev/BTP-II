"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import Card from "./_component/Card";
import useBuilderStore from "../../../store/builderStore";

const MyProperties = () => {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  // Zustand store state and actions
  const {
    builderData,
    builderToken,
    // loading,
    setBuilderToken,
    fetchBuilderProfileData,
    logoutBuilder,
  } = useBuilderStore();

  const [properties, setProperties] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("builderToken");
    if (!token) {
      router.push("/log-in");
    } else {
      setBuilderToken(token);
      fetchBuilderProfileData();
    }
  }, [router, setBuilderToken, fetchBuilderProfileData]);

  useEffect(() => {
    if (!builderData) return;

    const fetchBuilderProperty = async () => {
      try {
        const response = await fetch(`/api/${builderData._id}`);
        if (!response.ok) throw new Error("Error fetching properties");

        const data = await response.json();
        setProperties(data.properties || []);
        setLoading(false);
      } catch (error) {
        console.error("Error in fetching builder properties", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBuilderProperty();
  }, [builderData]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="w-8 h-8 border-4 border-gray-200 border-t-gray-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white p-2">
      {/* Header */}
      <div className="flex w-full bg-white items-center gap-4 mb-3.5 z-20 fixed top-0 left-0 right-0 p-4 shadow-md">
        <ArrowLeft
          size={28}
          className="cursor-pointer hover:text-gray-700"
          onClick={() => router.back()}
        />
        <h1 className="text-2xl font-bold">My Properties</h1>
      </div>

      {/* Property List */}
      {/* <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-2 pt-16">
        {properties?.length > 0 ? (
          properties?.map((property) => (
            <Card key={property?._id} property={property} />
          ))
        ) : (
          <p className="text-center col-span-full text-gray-500">
            No properties available
          </p>
        )}
      </div> */}

      {/* Property List */}
      {/* <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-2 pt-16">
        {properties?.map((property) => (
          <Card key={property?._id} property={property} />
        ))}
      </div> */}
      {/* Property List */}
      {/* Property List */}
      <div className="mt-2 pt-16">
        {properties.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {properties.map((property) => (
              <Card key={property?._id} property={property} />
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center min-h-[60vh]">
            <p className="text-center text-gray-500 text-lg font-medium">
              You have not added any properties yet.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyProperties;
