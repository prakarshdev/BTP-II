// "use client";

// import React from "react";
// import { useRouter } from "next/navigation";

// const Card = ({ property }) => {
//   const router = useRouter();

//   return (
//     <div
//       className="flex flex-col gap-2 p-4 rounded-lg bg-white cursor-pointer hover:shadow-lg transition-shadow"
//       onClick={() => router.push(`/builder/builderProperty/${property?._id}`)}
//     >
//       <div className="rounded-2xl overflow-hidden h-[200px] relative">
//         <img
//           src={property?.mediaFiles[0] || "/properties/property1.png"} // Use real image or fallback
//           alt={property?.projectName}
//           className="object-cover w-full h-full"
//         />
//       </div>
//       <div className="space-y-1">
//         <div className="flex justify-between items-start">
//           <h1 className="text-xl font-bold">{property?.projectName}</h1>
//           <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm">
//             {property?.projectStatus || "Under Construction"}
//           </span>
//         </div>

//         <div className="flex items-center gap-2 text-gray-600">
//           <span>{property?.typeOfProperty}</span>
//           <span>•</span>
//           <span>{property?.configuration} BHK</span>
//           <span>•</span>
//           <span>{property?.furnishingStatus || "Furnished"}</span>
//         </div>

//         <div className="flex items-center gap-1 text-sm text-gray-500">
//           <svg
//             xmlns="http://www.w3.org/2000/svg"
//             className="h-4 w-4"
//             fill="none"
//             viewBox="0 0 24 24"
//             stroke="currentColor"
//           >
//             <path
//               strokeLinecap="round"
//               strokeLinejoin="round"
//               strokeWidth={2}
//               d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
//             />
//             <path
//               strokeLinecap="round"
//               strokeLinejoin="round"
//               strokeWidth={2}
//               d="M15 11a3 3 0 11-6 0 3 3 0z"
//             />
//           </svg>
//           <span>{property.location || "Unknown Location"}</span>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Card;

"use client";

import React from "react";
import { useRouter } from "next/navigation";

const Card = ({ property }) => {
  const router = useRouter();

  return (
    <div
      className="flex flex-col gap-2 p-4 rounded-lg bg-white cursor-pointer hover:shadow-lg transition-shadow"
      onClick={() => router.push(`/builder/builderProperty/${property?._id}`)}
    >
      <div className="rounded-2xl overflow-hidden h-[200px] relative">
        <img
          src={property?.mediaFiles?.[0] || "/properties/property1.png"} // Use real image or fallback
          alt={property?.projectName}
          className="object-cover w-full h-full"
        />
      </div>
      <div className="space-y-1">
        <div className="flex justify-between items-start">
          <h1 className="text-xl font-bold">{property?.projectName}</h1>
          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm">
            {property?.projectStatus || "Under Construction"}
          </span>
        </div>

        <div className="flex items-center gap-2 text-gray-600">
          <span>{property?.typeOfProperty}</span>
          <span>•</span>
          <span>{property?.configuration} BHK</span>
          <span>•</span>
          <span>{property?.furnishingStatus || "Furnished"}</span>
        </div>

        {/* Corrected SVG */}
        <div className="flex items-center gap-1 text-sm text-gray-500">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            {/* Corrected Path Data */}
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 2C8.134 2 5 5.134 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.866-3.134-7-7-7zm0 10a3 3 0 110-6 3 3 0 010 6z"
            />
          </svg>
          <span>{property.location || "Unknown Location"}</span>
        </div>
      </div>
    </div>
  );
};

export default Card;
