"use client";
import React, { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useRouter } from "next/navigation";
import { useParams } from "next/navigation";
import DeleteButton from "./_components/DeleteButton";
import useBuilderStore from "../../../../store/builderStore";

const BuilderPropertyPage = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const router = useRouter();
  const params = useParams();
  const propertyid = params.propertyid;
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);

  // Zustand store state and actions
  const {
    builderData,
    builderToken,
    setBuilderToken,
    fetchBuilderProfileData,
    logoutBuilder,
  } = useBuilderStore();

  useEffect(() => {
    const token = localStorage.getItem("builderToken");
    if (!token) {
      router.push("/log-in");
    } else {
      setBuilderToken(token);
      fetchBuilderProfileData();
    }
  }, [router, setBuilderToken, fetchBuilderProfileData]);

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === property?.mediaFiles.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? property?.mediaFiles.length - 1 : prevIndex - 1
    );
  };

  useEffect(() => {
    const fetchPropertyData = async () => {
      try {
        const response = await fetch(`/api/getproperty/${propertyid}`);
        if (response.ok) {
          const data = await response.json();
          setProperty(data.property);
          setLoading(false);
        } else {
          console.error("Error fetching property data");
        }
      } catch (error) {
        console.error("Error fetching property data", error);
      }
    };
    fetchPropertyData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="w-8 h-8 border-4 border-gray-200 border-t-gray-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col pb-16">
      {/* Image Carousel */}
      <div className="relative h-[45vh]">
        <div
          className="flex justify-between bg-cover bg-center h-full w-full transition-opacity duration-500"
          style={{
            backgroundImage: `url(${property?.mediaFiles[currentImageIndex]})`,
          }}
        >
          <ChevronLeft
            className="text-white w-8 h-8 mt-4 ml-4 relative z-10 cursor-pointer"
            onClick={() => router.back()}
          />
        </div>
        <div className="absolute inset-0 flex items-center justify-between p-4">
          <button
            onClick={prevImage}
            className="bg-black/50 text-white rounded-full p-2 hover:bg-black/70 transition-all"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextImage}
            className="bg-black/50 text-white rounded-full p-2 hover:bg-black/70 transition-all"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Property Details */}
      <div className="flex-1 p-6 bg-white rounded-2xl">
        <div className="flex justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">
            {property?.projectName}
          </h1>
          <DeleteButton propertyid={propertyid} soldStatus={property?.soldStatus}/>
        </div>

        <p className="text-gray-600 text-sm mt-1">{property?.address}</p>

        <div className="grid grid-cols-2 gap-4 mt-4 text-gray-800">
          <div>{property?.configuration} BHK</div>
          <div>
            {property?.builtUpArea} sqft Built-up | {property?.carpetArea} sqft
            Carpet
          </div>
          <div>Status: {property?.projectStatus}</div>
          <div>
            Possession:{" "}
            {new Date(property?.possessionDate).toLocaleDateString()}
          </div>
          <div className="font-semibold">
            Price: ₹{property?.price.toLocaleString()}
          </div>
          <div>Maintenance: ₹{property?.maintenanceCharges}/month</div>
          <div>Parking: {property?.parkingAvailability}</div>
          <div>Furnishing: {property?.furnishingStatus}</div>
        </div>
      </div>
    </div>
  );
};

export default BuilderPropertyPage;
