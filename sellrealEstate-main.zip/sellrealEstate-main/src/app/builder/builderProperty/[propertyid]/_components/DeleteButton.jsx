"use client";

import React, { useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { useRouter } from "next/navigation";

const DeleteButton = ({ propertyid, soldStatus }) => {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleDelete = async () => {
    if (!soldStatus) {
      toast.error("Only sold properties can be deleted");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/delete-property", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: propertyid }),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success("Property deleted successfully");
        setTimeout(() => {
          router.push("/builder/builderProperty");
        }, 1500); // give toast time to show
      } else {
        toast.error(data.message || "Failed to delete property");
      }
    } catch (error) {
      toast.error("Something went wrong");
      console.error("Delete error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={`text-white px-4 py-1 rounded-xl w-[105px] flex justify-center
        ${soldStatus ? "bg-red-600 hover:bg-red-700" : "bg-gray-400"}
      `}
    >
      <button
        onClick={handleDelete}
        disabled={!soldStatus || loading}
        className="font-bold w-full cursor-pointer disabled:cursor-not-allowed"
      >
        {soldStatus ? (loading ? "Deleting..." : "Delete") : "Unsold"}
      </button>
      <Toaster position="top-right" />
    </div>
  );
};

export default DeleteButton;
