import React, { useState } from "react";
import { Edit } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

const BuilderProfileCard = ({ onClose }) => {
  const router = useRouter();
  const [builderData, setBuilderData] = useState(null);
  const [builderToken, setBuilderToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const builderToken = localStorage.getItem("builderToken");
    if (!builderToken) {
      router.push("/log-in");
      return;
    }
    setBuilderToken(builderToken);
  }, []);

  useEffect(() => {
    if (!builderToken) {
      // router.push("/log-in");
      return;
    }
    const fetchbuilderProfileData = async () => {
      try {
        const response = await fetch("/api/auth/builder-logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${builderToken}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          const builderInfo = data.builderDetails;
          setBuilderData(builderInfo);
          setLoading(false);
        } else {
          console.error("getting error in brokerInfo");
        }
      } catch (error) {
        console.log("error in token api", error);
        setLoading(false);
      }
    };
    fetchbuilderProfileData();
  }, [builderToken]);

  // handle logout button
  const handleLogout = () => {
    const builderToken = localStorage.getItem("builderToken");
    if (!builderToken) {
      return;
    }
    localStorage.removeItem("builderToken");
    localStorage.removeItem("builderId");
    localStorage.removeItem("builderName");
    router.push("/log-in");
  };

  if (loading) {
    return (
      <div>
        <div className="w-8 h-8 border-4 border-gray-200 border-t-gray-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className=" fixed right-0 top-0 p-6 border border-gray-400 rounded-2xl shadow-lg bg-white w-[260px] h-[450px] text-gray-800">
      <div className="flex justify-between items-center mb-2">
        <Edit
          className="cursor-pointer text-gray-600 hover:text-gray-900"
          size={20}
        />
        <button
          className="text-gray-600 hover:text-gray-900 text-2xl"
          onClick={onClose}
        >
          &times;
        </button>
      </div>
      <img
        src={builderData?.builderImage}
        alt={builderData?.name}
        className="w-60 h-40 object-contain rounded-xl border border-gray-400"
      />
      <h2 className="text-xl font-bold mt-2 text-gray-900">
        {builderData?.name}
      </h2>
      <div className="mt-2 border-t border-gray-400 pt-2 flex flex-col gap-1">
        <p className="text-base">
          RERA : <span className="font-medium">{builderData?.reraNumber}</span>
        </p>
        <p className="text-base">
          Location: <span className="font-medium">{builderData?.location}</span>
        </p>
        <p className="text-base">
          Property Type:{" "}
          <span className="font-medium">{builderData?.propertyType}</span>
        </p>
        <p className="text-base">
          Contact: <span className="font-medium">{builderData?.contact}</span>
        </p>
        <button
          className="bg-black text-white font-semibold text-xl rounded-xl py-1 mt-2"
          onClick={handleLogout}
        >
          log out
        </button>
      </div>
    </div>
  );
};

export default BuilderProfileCard;
