const Property = require("../../../model/add-property-model");
import { NextResponse } from "next/server";
import connectDB from "../../../lib/db";

export async function POST(req) {
  try {
    await connectDB();
    const {
      builderId,
      projectName,
      typeOfProperty,
      configuration,
      projectStatus,
      possessionDate,
      launchDate,
      address,
      nearbyLandmarks,
      transportAccessibilityScore,
      builtUpArea,
      carpetArea,
      price,
      maintenanceCharges,
      expectedRentalYield,
      brokerage,
      paymentPlans,
      floorDetails,
      legalStatus,
      approvingAuthorities,
      numberOfBathrooms,
      numberOfBalconies,
      parkingAvailability,
      furnishingStatus,
      aiGeneratedCatalogue,
      mediaFiles,
    } = await req.json();

    if (
      !projectName ||
      !typeOfProperty ||
      !configuration ||
      !projectStatus ||
      !possessionDate ||
      !launchDate ||
      !address ||
      !nearbyLandmarks ||
      !transportAccessibilityScore ||
      !builtUpArea ||
      !carpetArea ||
      !price ||
      !maintenanceCharges ||
      !expectedRentalYield ||
      !brokerage ||
      !paymentPlans ||
      !floorDetails ||
      !legalStatus ||
      !approvingAuthorities ||
      !numberOfBathrooms ||
      !numberOfBalconies ||
      !parkingAvailability ||
      !furnishingStatus ||
      !aiGeneratedCatalogue ||
      !mediaFiles
    ) {
      return NextResponse.json(
        { message: "Missing required fields" },
        { status: 400 }
      );
    }

    const existingProperty = await Property.findOne({
      projectName,
      typeOfProperty,
      configuration,
      projectStatus,
      possessionDate,
    });

    if (existingProperty) {
      return NextResponse.json(
        { message: "Property already exists" },
        { status: 400 }
      );
    }

    const newProperty = new Property({
      builderId,
      projectName,
      typeOfProperty,
      configuration,
      projectStatus,
      possessionDate,
      launchDate,
      address,
      nearbyLandmarks,
      transportAccessibilityScore,
      builtUpArea,
      carpetArea,
      price,
      maintenanceCharges,
      expectedRentalYield,
      brokerage,
      paymentPlans,
      floorDetails,
      legalStatus,
      approvingAuthorities,
      numberOfBathrooms,
      numberOfBalconies,
      parkingAvailability,
      furnishingStatus,
      aiGeneratedCatalogue,
      mediaFiles,
    });

    await newProperty.save();

    return NextResponse.json(
      { message: "Property added successfully" },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error adding property:", error);
    return NextResponse.json(
      { message: "Error adding property" },
      { status: 500 }
    );
  }
}