import connectDB from "../../../lib/db";
import Connection from "../../../model/connection-model";
import { NextResponse } from "next/server";
import mongoose from "mongoose";

export async function GET(req) {
  try {
    await connectDB();
    const { searchParams } = new URL(req.url);
    const builderId = searchParams.get("builderId");

    if (!builderId) {
      return NextResponse.json(
        { message: "Builder ID is required" },
        { status: 400 }
      );
    }

    const objectIdBuilderId = new mongoose.Types.ObjectId(builderId);

    const brokerRequests = await Connection.find({
      builderId: objectIdBuilderId,
    })
      .populate("brokerId")
      .lean();

    if (brokerRequests.length === 0) {
      return NextResponse.json(
        { message: "No broker requests found", success: true, brokers: [] },
        { status: 200 }
      );
    }

    const brokers = brokerRequests.map((request) => {
      if (request.brokerId && request.brokerId.password) {
        delete request.brokerId.password;
      }

      return {
        ...request.brokerId,
        connectionId: request._id,
        status: "pending",
      };
    });

    return NextResponse.json(
      { success: true, brokers: brokers },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error fetching broker requests:", error);
    return NextResponse.json(
      { message: "Internal server error" },
      { status: 500 }
    );
  }
}
