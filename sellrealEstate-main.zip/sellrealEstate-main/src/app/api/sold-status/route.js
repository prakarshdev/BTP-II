import connectDB from "../../../lib/db";
import Property from "../../../model/add-property-model";
import { NextResponse } from "next/server";

export async function PATCH(req) {
  try {
    const { id } = await req.json();

    if (!id) {
      return NextResponse.json(
        { message: "Property ID is required" },
        { status: 400 }
      );
    }

    await connectDB();

    const property = await Property.findById(id);

    if (!property) {
      return NextResponse.json(
        { message: "Property not found" },
        { status: 404 }
      );
    }

    if (property.soldStatus === true) {
      return NextResponse.json(
        { message: "You already sold this property" },
        { status: 400 }
      );
    }

    property.soldStatus = true;
    await property.save();

    return NextResponse.json(
      {
        message: "Property marked as sold",
        property,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error marking property as sold:", error);
    return NextResponse.json(
      { message: "Internal Server Error" },
      { status: 500 }
    );
  }
}
