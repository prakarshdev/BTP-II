import connectDB from "../../../../lib/db";
import ConnectionRequest from "../../../../model/connection-model";
import { NextResponse } from "next/server";

export async function GET(req, { params }) {
  try {
    await connectDB();
    const { builderId } = await params;
    const requests = await ConnectionRequest.find({
      builderId,
    }).populate("brokerId propertyId");

    return NextResponse.json(requests);
  } catch (error) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}
