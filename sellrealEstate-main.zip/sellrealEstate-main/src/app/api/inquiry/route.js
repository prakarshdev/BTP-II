const Inquiry = require("../../../model/inquiry-model");
import { NextResponse } from "next/server";
import connectDB from "../../../lib/db";
// POST request to create a new inquiry
export async function POST(req) {
  try {
    await connectDB();
    const { name, contact, location, area, searching, brokerage, question } =
      await req.json();

    // Validate required fields
    if (!name || !contact || !location || !area || !searching || !brokerage) {
      return NextResponse.json(
        { message: "Missing required fields" },
        { status: 400 }
      );
    }

    const newInquiry = new Inquiry({
      name,
      contact,
      location,
      area,
      searching,
      brokerage,
      question,
    });

    await newInquiry.save();

    return NextResponse.json(
      {
        message: "Inquiry created successfully",
        success: true,
        newInquiry,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating inquiry:", error);
    return NextResponse.json(
      { message: error.message || "Error creating inquiry" },
      { status: 500 }
    );
  }
}
