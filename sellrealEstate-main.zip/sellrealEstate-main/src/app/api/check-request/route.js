// app/api/check-request/route.js

import { NextResponse } from "next/server";
import connectDB from "../../../lib/db";
import ConnectionRequest from "../../../model/connection-model";

export async function GET(req) {
  try {
    await connectDB();
    const { searchParams } = new URL(req.url);
    const brokerId = searchParams.get("brokerId");
    const builderId = searchParams.get("builderId");
    const propertyId = searchParams.get("propertyId");

    if (!brokerId || !builderId || !propertyId) {
      return NextResponse.json(
        { success: false, message: "Missing query params" },
        { status: 400 }
      );
    }

    const request = await ConnectionRequest.findOne({
      brokerId,
      builderId,
      propertyId,
    });

    return NextResponse.json({ success: true, request });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}
