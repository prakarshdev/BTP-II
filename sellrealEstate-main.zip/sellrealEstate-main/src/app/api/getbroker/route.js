import connectDB from "../../../lib/db";
import Broker from "../../../model/broker-model";
import { NextResponse } from "next/server";

// API to fetch all brokers
export async function GET() {
  try {
    await connectDB();

    const brokers = await Broker.find({});

    return NextResponse.json(
      {
        message: "Brokers fetched successfully",
        success: true,
        brokers,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error fetching brokers:", error);
    return NextResponse.json(
      {
        message: "Internal server error while fetching brokers",
        success: false,
      },
      { status: 500 }
    );
  }
}
