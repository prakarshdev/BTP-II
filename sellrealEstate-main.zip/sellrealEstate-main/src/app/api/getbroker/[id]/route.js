import connectDB from "../../../../lib/db";
import Broker from "../../../../model/broker-model";
import { NextResponse } from "next/server";

// API to fetch a single broker by id
export async function GET(req, { params }) {
  try {
    await connectDB();
    const { id } = await params;
    if (!id) {
      return NextResponse.json(
        {
          message: "Broker id is required",
          success: false,
        },
        { status: 400 }
      );
    }

    const broker = await Broker.findOne({ _id: id });

    if (!broker) {
      return NextResponse.json(
        {
          message: "Broker not found",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "Broker fetched successfully",
        success: true,
        broker,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error fetching broker:", error);
    return NextResponse.json(
      {
        message: "Internal server error while fetching broker",
        success: false,
      },
      { status: 500 }
    );
  }
}
