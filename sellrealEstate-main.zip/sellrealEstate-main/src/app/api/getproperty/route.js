import { NextResponse } from "next/server";
import connectDB from "../../../lib/db";
import Property from "../../../model/add-property-model";

export async function GET(req) {
  try {
    await connectDB();

    // Fetch all properties
    const properties = await Property.find();

    return NextResponse.json({ success: true, properties }, { status: 200 });
  } catch (error) {
    console.error("Error fetching properties:", error);
    return NextResponse.json(
      { success: false, message: "Error fetching properties" },
      { status: 500 }
    );
  }
}
