import { NextResponse } from "next/server";
import connectDB from "../../../../lib/db";
import Property from "../../../../model/add-property-model";

export async function GET(req, { params }) {
  try {
    await connectDB();
    const { id } = await params;

    if (!id) {
      return NextResponse.json(
        { success: false, message: "Project id is required" },
        { status: 400 }
      );
    }

    const property = await Property.findOne({
      _id: id,
    });

    if (!property) {
      return NextResponse.json(
        { success: false, message: "Property not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, property }, { status: 200 });
  } catch (error) {
    console.error("Error fetching property:", error);
    return NextResponse.json(
      { success: false, message: "Error fetching property" },
      { status: 500 }
    );
  }
}
