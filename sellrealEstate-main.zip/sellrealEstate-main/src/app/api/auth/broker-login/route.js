import connectDB from "../../../../lib/db";
import Broker from "../../../../model/broker-model";
import { NextResponse } from "next/server";
import jwt from "jsonwebtoken";
const bcrypt = require("bcryptjs");

// API for broker login
export async function POST(req) {
  try {
    await connectDB();
    const { phoneNumber, password } = await req.json();

    // Check if broker exists
    const broker = await Broker.findOne({ phoneNumber });
    if (!broker) {
      return NextResponse.json(
        {
          message: "Invalid phone number or password",
          success: false,
        },
        { status: 401 }
      );
    }

    // Validate password
    const isPasswordValid = broker.comparePassword(password);
    if (!isPasswordValid) {
      return NextResponse.json(
        {
          message: "Invalid phone number or password",
          success: false,
        },
        { status: 401 }
      );
    }

    // Generate JWT token
    const token = broker.generateAuthToken();

    return NextResponse.json(
      {
        message: "Login successful",
        success: true,
        token,
        broker,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Broker login error:", error);
    return NextResponse.json(
      {
        message: "Internal server error during broker login",
        success: false,
      },
      { status: 500 }
    );
  }
}
