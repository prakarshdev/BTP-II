import connectDB from "../../../../lib/db";
import Builder from "../../../../model/builder-model";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";

export async function POST(req) {
  try {
    await connectDB();
    const { contact, password } = await req.json();

    const builder = await Builder.findOne({ contact });

    if (!builder) {
      return NextResponse.json(
        { message: "Invalid credentials, builder not found", success: false },
        { status: 401 }
      );
    }

    const isPasswordValid = builder.comparePassword(password);

    if (!isPasswordValid) {
      return NextResponse.json(
        { message: "Invalid credentials, incorrect password", success: false },
        { status: 401 }
      );
    }

    const token = builder.generateAuthToken();

    return NextResponse.json(
      {
        message: "Builder logged in successfully",
        success: true,
        token,
        builder,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error during builder login:", error);
    return NextResponse.json(
      { message: "Internal server error during builder login", success: false },
      { status: 500 }
    );
  }
}
