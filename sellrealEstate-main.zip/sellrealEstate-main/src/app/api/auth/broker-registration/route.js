// import connectDB from "../../../../lib/db";
// import Broker from "../../../../model/broker-model";
// import { NextResponse } from "next/server";
// import jwt from "jsonwebtoken";
// const bcrypt = require("bcryptjs");
// import { brokerValidator } from "../../../../validators/brokerValidator";

// // api for broker registration
// export async function POST(req) {
//   try {
//     await connectDB();
//     const {
//       profilePicture,
//       fullName,
//       dateOfBirth,
//       phoneNumber,
//       companyName,
//       businessAddress,
//       yearOfExperience,
//       reraRegistrationNumber,
//       cities,
//       totalPropertiesSold,
//       pastDealClosures,
//       averageTimeToCloseDeal,
//       preferredPropertyType,
//       brokerageFeeStructure,
//       marketingPlatformUsed,
//       adsPlatformUsed,
//       password,
//       aiRecommendations,
//       autoSuggestions,
//       aiGeneratedContent,
//     } = await req.json();

//     const broker = await Broker.findOne({
//       fullName,
//       dateOfBirth,
//       phoneNumber,
//       companyName,
//     });

//     if (broker) {
//       return NextResponse.json(
//         {
//           message: "Broker already exists",
//           success: false,
//         },
//         { status: 409 }
//       );
//     }

//     const hashedPassword = await bcrypt.hash(password, 10);

//     const newBroker = new Broker({
//       profilePicture,
//       fullName,
//       dateOfBirth,
//       phoneNumber,
//       companyName,
//       businessAddress,
//       yearOfExperience,
//       reraRegistrationNumber,
//       cities,
//       totalPropertiesSold,
//       pastDealClosures,
//       averageTimeToCloseDeal,
//       preferredPropertyType,
//       brokerageFeeStructure,
//       marketingPlatformUsed,
//       password: hashedPassword,
//       adsPlatformUsed,
//       aiRecommendations,
//       autoSuggestions,
//       aiGeneratedContent,
//     });

//     await newBroker.save();
//     const token = newBroker.generateAuthToken();

//     return NextResponse.json(
//       {
//         message: "Broker registered successfully",
//         success: true,
//         token,
//         brokerId: newBroker._id,
//       },
//       { status: 201 }
//     );
//   } catch (error) {
//     console.error("Broker registration error:", error);
//     return NextResponse.json(
//       {
//         message: "Internal server error during broker registration",
//         success: false,
//       },
//       { status: 500 }
//     );
//   }
// }

import connectDB from "../../../../lib/db";
import Broker from "../../../../model/broker-model";
import { NextResponse } from "next/server";
import jwt from "jsonwebtoken";
const bcrypt = require("bcryptjs");
import { brokerPartialValidator } from "../../../../validators/brokerValidator"; // Assuming you export it from the same file

// api for broker registration
export async function POST(req) {
  try {
    await connectDB();
    const data = await req.json();

    // Validate only phoneNumber and password
    const parsed = brokerPartialValidator.safeParse({
      phoneNumber: data.phoneNumber,
      password: data.password,
    });

    if (!parsed.success) {
      const errorMessages = parsed.error.errors.map((err) => err.message);
      return NextResponse.json(
        {
          message: errorMessages.join(" and "),
          success: false,
        },
        { status: 400 }
      );
    }

    const {
      profilePicture,
      fullName,
      dateOfBirth,
      phoneNumber,
      companyName,
      businessAddress,
      yearOfExperience,
      reraRegistrationNumber,
      cities,
      totalPropertiesSold,
      pastDealClosures,
      averageTimeToCloseDeal,
      preferredPropertyType,
      brokerageFeeStructure,
      marketingPlatformUsed,
      adsPlatformUsed,
      password,
      aiRecommendations,
      autoSuggestions,
      aiGeneratedContent,
    } = data;

    const broker = await Broker.findOne({
      fullName,
      dateOfBirth,
      phoneNumber,
      companyName,
    });

    if (broker) {
      return NextResponse.json(
        {
          message: "Broker already exists",
          success: false,
        },
        { status: 409 }
      );
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newBroker = new Broker({
      profilePicture,
      fullName,
      dateOfBirth,
      phoneNumber,
      companyName,
      businessAddress,
      yearOfExperience,
      reraRegistrationNumber,
      cities,
      totalPropertiesSold,
      pastDealClosures,
      averageTimeToCloseDeal,
      preferredPropertyType,
      brokerageFeeStructure,
      marketingPlatformUsed,
      password: hashedPassword,
      adsPlatformUsed,
      aiRecommendations,
      autoSuggestions,
      aiGeneratedContent,
    });

    await newBroker.save();
    const token = newBroker.generateAuthToken();

    return NextResponse.json(
      {
        message: "Broker registered successfully",
        success: true,
        token,
        brokerId: newBroker._id,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Broker registration error:", error);
    return NextResponse.json(
      {
        message: "Internal server error during broker registration",
        success: false,
      },
      { status: 500 }
    );
  }
}
