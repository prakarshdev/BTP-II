import { NextResponse } from "next/server";
import connectDB from "../../../../lib/db";
import User from "../../../../model/user-model";
import { userValidator } from "../../../../validators/userValidator";
import jwt from "jsonwebtoken";

// POST request to create a new normal user
export async function POST(req) {
  try {
    await connectDB();
    const { countryCode, mobileNumber } = await req.json();

    // Zod validation
    const parsed = userValidator.safeParse({
      countryCode,
      mobileNumber: mobileNumber.toString(), // convert for regex validation
    });

    if (!parsed.success) {
      const errorMessages = parsed.error.errors.map((err) => err.message);
      return NextResponse.json(
        { message: errorMessages.join(" and "), success: false },
        { status: 400 }
      );
    }

    const user = await User.findOne({ countryCode, mobileNumber });
    if (user) {
      try {
        const token = user.generateAuthToken();
        return NextResponse.json({
          message: "User already exists",
          user,
          token,
        });
      } catch (tokenError) {
        return NextResponse.json(
          {
            message: "Authentication failed",
            error: tokenError.message,
          },
          { status: 500 }
        );
      }
    }
    const newUser = new User({ countryCode, mobileNumber });
    await newUser.save();
    try {
      const token = newUser.generateAuthToken();
      return NextResponse.json({
        message: "User created successfully",
        user: newUser,
        token,
      });
    } catch (tokenError) {
      return NextResponse.json(
        {
          message: "User created but authentication failed",
          user: newUser,
          error: tokenError.message,
        },
        { status: 500 }
      );
    }
  } catch (error) {
    return NextResponse.json({
      message: "User creation failed",
      error: error.message,
    });
  }
}
