
import jwt from "jsonwebtoken";
import { NextResponse } from "next/server";
import Broker from "../../../../model/broker-model";

const SECRET_KEY = process.env.JWT_SECRET_KEY || "your-secret-key";

export async function POST(req) {

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { message: "Authorization token is required" },
        { status: 400 }
      );
    }

    const brokerToken = authHeader.split(" ")[1];
    const decoded = jwt.verify(brokerToken, SECRET_KEY);
    const brokerId = decoded?._id;

    if (!brokerId) {
      return NextResponse.json(
        { message: "Invalid token structure" },
        { status: 401 }
      );
    }

    // Fetch broker directly from the database
    const brokerDetails = await Broker.findOne({ _id: brokerId });

    if (!brokerDetails) {
      return NextResponse.json(
        { message: "Broker not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { message: "Token verified", brokerDetails },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { message: "Invalid or expired token", error: error.message },
      { status: 401 }
    );
  }
}
