import jwt from "jsonwebtoken";
import { NextResponse } from "next/server";
import Builder from "../../../../model/builder-model";
const SECRET_KEY = process.env.JWT_SECRET_KEY || "your-secret-key";

export async function POST(req) {

  try {
    const authHeader = req.headers.get("authorization");

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { message: "Authorization token is required" },
        { status: 400 }
      );
    }

    const builderToken = authHeader.split(" ")[1];

    // Verify the token
    const decoded = jwt.verify(builderToken, SECRET_KEY);
    const builderId = decoded?._id;

    if (!builderId) {
      return NextResponse.json(
        { message: "Invalid token structure" },
        { status: 401 }
      );
    }

    //Fetch builder details from database
    const builderDetails = await Builder.findOne({ _id: builderId });

    if (!builderDetails) {
      return NextResponse.json(
        { message: "Builder not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { message: "authorized builder Details", builderDetails },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { message: "Invalid or expired token", error: error.message },
      { status: 401 }
    );
  }
}
