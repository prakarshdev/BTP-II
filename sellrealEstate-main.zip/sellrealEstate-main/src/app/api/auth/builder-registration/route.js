import connectDB from "../../../../lib/db";
import Builder from "../../../../model/builder-model";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { builderValidator } from "../../../../validators/builderValidator";

export async function POST(req) {
  try {
    await connectDB();

    // Parse the request body
    const body = await req.json();

    // Validate contact and password using Zod
    const parsed = builderValidator.safeParse({
      contact: body.contact,
      password: body.password,
    });

    if (!parsed.success) {
      const errorMessages = parsed.error.errors.map((err) => err.message);
      return NextResponse.json(
        { message: errorMessages.join(" and "), success: false },
        { status: 400 }
      );
    }

    // Validate required fields
    if (
      !body.name ||
      !body.reraNumber ||
      !body.location ||
      !body.propertyType ||
      !body.contact ||
      !body.password
    ) {
      return NextResponse.json(
        { message: "All fields are required" },
        { status: 400 }
      );
    }

    // Check if the builder already exists with the same reraNumber
    const existingReraNumber = await Builder.findOne({
      reraNumber: body.reraNumber,
    });
    if (existingReraNumber) {
      return NextResponse.json(
        { message: "Builder with this RERA number already exists" },
        { status: 400 }
      );
    }

    // Check if the builder already exists with the same contact
    const existingContact = await Builder.findOne({ contact: body.contact });
    if (existingContact) {
      return NextResponse.json(
        { message: "Builder with this contact number already exists" },
        { status: 400 }
      );
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(body.password, 10);

    // Create a new builder instance
    const newBuilder = new Builder({
      builderImage: body.builderImage || "",
      name: body.name,
      reraNumber: body.reraNumber,
      location: body.location,
      propertyType: body.propertyType,
      contact: body.contact,
      password: hashedPassword,
    });

    // Save the builder to the database
    await newBuilder.save();

    // Generate auth token
    const token = await newBuilder.generateAuthToken();

    return NextResponse.json(
      {
        message: "Builder registered successfully",
        token,
        builder: {
          id: newBuilder._id,
          name: newBuilder.name,
          reraNumber: newBuilder.reraNumber,
          location: newBuilder.location,
          propertyType: newBuilder.propertyType,
          contact: newBuilder.contact,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error during builder registration:", error);
    return NextResponse.json(
      {
        message: "Builder registration failed",
        error: error.message,
      },
      { status: 500 }
    );
  }
}
