import connectDB from "../../../lib/db";
import Builder from "../../../model/builder-model";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    await connectDB();

    const builder = await Builder.find();

    return NextResponse.json(builder, { status: 200 });
  } catch (error) {
    console.error("Error fetching builders:", error);
    return NextResponse.json(
      { message: "Failed to fetch builders" },
      { status: 500 }
    );
  }
}
