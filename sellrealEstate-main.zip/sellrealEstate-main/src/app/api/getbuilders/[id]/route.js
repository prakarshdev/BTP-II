import connectDB from "../../../../lib/db";
import Builder from "../../../../model/builder-model";
import { NextResponse } from "next/server";

// API to fetch a single broker by id
export async function GET(req, { params }) {
  try {
    await connectDB();
    const { id } = await params;
    if (!id) {
      return NextResponse.json(
        {
          message: "Builder id is required",
          success: false,
        },
        { status: 400 }
      );
    }

    const builder = await Builder.findOne({ _id: id });

    if (!builder) {
      return NextResponse.json(
        {
          message: "Builder not found",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "Builder fetched successfully",
        success: true,
        builder,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error fetching broker:", error);
    return NextResponse.json(
      {
        message: "Internal server error while fetching broker",
        success: false,
      },
      { status: 500 }
    );
  }
}