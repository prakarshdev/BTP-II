import { NextResponse } from "next/server";
import connectDB from "../../../../lib/db";
import ConnectionRequest from "../../../../model/connection-model";

export async function PUT(req, { params }) {
  try {
    await connectDB();
    const { status } = await req.json();
    const { id } = await params;

    if (status === "rejected") {
      await ConnectionRequest.findByIdAndDelete(id.trim());
      return NextResponse.json({
        success: true,
        message: "Request rejected and deleted",
      });
    }

    const updatedRequest = await ConnectionRequest.findByIdAndUpdate(
      id.trim(),
      { status },
      { new: true }
    );

    if (!updatedRequest)
      return NextResponse.json(
        { success: false, message: "Request not found" },
        { status: 404 }
      );

    return NextResponse.json({
      success: true,
      message: `Request ${status}`,
      updatedRequest,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}
