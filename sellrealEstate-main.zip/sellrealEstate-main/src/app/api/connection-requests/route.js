import { NextResponse } from "next/server";
import connectDB from "../../../lib/db";
import ConnectionRequest from "../../../model/connection-model";

export async function POST(req) {
  try {
    await connectDB();
    const { brokerId, builderId, propertyId } = await req.json();

    const existingRequest = await ConnectionRequest.findOne({
      brokerId: brokerId,
      builderId: builderId,
      propertyId: propertyId,
    });

    if (existingRequest) {
      return NextResponse.json({
        message: "Requsts already sent",
        success: true,
        existingRequest,
      });
    }

    const newRequest = new ConnectionRequest({
      brokerId,
      builderId,
      propertyId,
    });

    await newRequest.save();

    return NextResponse.json({
      success: true,
      message: "Request sent successfully!",
      newRequest,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 }
    );
  }
}
