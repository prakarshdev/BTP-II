"use client";
import Header from "./_components/Header";
import ClientTableHeader from "./_components/ClientTableHeader";
import ClientRow from "./_components/ClientRow";

const clients = [
  {
    id: 1,
    name: "Bessie Cooper",
    profile: "/assets/user.jpeg",
    property: "Azure Heaven",
    status: "online",
  },
  {
    id: 2,
    name: "Ralph Edwards",
    profile: "/assets/user.jpeg",
    property: "Golden Gates",
    status: "online",
  },
  {
    id: 3,
    name: "Floyd Miles",
    profile: "/assets/user.jpeg",
    property: "Grand Estate",
    status: "offline",
  },
  {
    id: 4,
    name: "Courtney Henry",
    profile: "/assets/user.jpeg",
    property: "Royal Villa",
    status: "offline",
  },
  {
    id: 5,
    name: "Darrell Steward",
    profile: "/assets/user.jpeg",
    property: "Palm Villa",
    status: "online",
  },
];

export default function ClientsPage() {
  return (
    <div className="p-4 max-w-md mx-auto">
      <Header title="Clients" />
      <ClientTableHeader />
      {clients.map((client) => (
        <ClientRow key={client.id} client={client} />
      ))}
    </div>
  );
}