import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Header({ title }) {
  const router = useRouter();
  return (
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center">
        <Link href="/">
          <button className="p-1" onClick={() => router.back()}>
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M15 19l-7-7 7-7"
              />
            </svg>
          </button>
        </Link>
        <h2 className="text-xl font-bold">{title}</h2>
      </div>
      <button className="px-3 py-1 bg-black text-white rounded-md text-sm flex items-center gap-1">
        <svg
          className="w-4 h-4"
          fill="none"
          stroke="currentColor"
          strokeWidth={2}
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 4v16m8-8H4"
          />
        </svg>
        Add client
      </button>
    </div>
  );
}
