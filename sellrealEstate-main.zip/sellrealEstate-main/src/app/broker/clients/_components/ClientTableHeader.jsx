import Image from "next/image";

export default function ClientTableHeader() {
  return (
    <div className="flex justify-between px-2 py-2 border-b text-gray-700 font-semibold text-sm">
      <span>Profile</span>
      <span className="ml-16">Property</span>
      <div className="flex gap-4">
        <Image
          src="/svgIcons/icon2.svg"
          alt="Share"
          width={20}
          height={20}
          className="w-5 h-5"
        />
        <Image
          src="/svgIcons/icon3.svg"
          alt="Share"
          width={20}
          height={20}
          className="w-5 h-5"
        />
      </div>
    </div>
  );
}
