import Image from "next/image";

export default function ClientRow({ client }) {
  return (
    <div className="flex justify-between items-center py-1.5 border-b">
      {/* Profile Section */}
      <div className="flex items-center gap-3">
        <Image
          src={client.profile}
          alt={client.name}
          width={40}
          height={40}
          className="w-10 h-10 rounded-full"
        />
        <span className="font-medium text-gray-800 truncate w-[100px]">
          {client.name}
        </span>
      </div>

      {/* Property Name */}
      <span className="text-sm text-gray-600 truncate w-[100px]">
        {client.property}
      </span>

      {/* Status and Actions */}
      <div className="flex items-center gap-7">
        {/* Status Indicator */}
        <div
          className={`w-3 h-3 rounded-full ${
            client.status === "online" ? "bg-green-500" : "bg-red-500"
          }`}
        ></div>
        <Image
          src="/svgIcons/icon1.svg"
          alt="Share"
          width={20}
          height={20}
          className="w-5 h-5 text-blue-500 cursor-pointer"
        />
      </div>
    </div>
  );
}
