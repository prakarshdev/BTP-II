import React from "react";
import Footer from "./_component/Footer";

const BrokerLayout = ({ children }) => {
  return (
    <div>
      {children}
      <Footer />
    </div>
  );
};

export default BrokerLayout;