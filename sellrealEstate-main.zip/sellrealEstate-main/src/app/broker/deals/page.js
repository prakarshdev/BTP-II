"use client";
import React, { use, useState } from "react";
import Image from "next/image";
import Badge from "./_component/Badge";
import { IoArrowBack } from "react-icons/io5";
import { useRouter } from "next/navigation";

const deals = [
  {
    propertyImage: "/properties/property1.png",
    propertyName: "Luxury Villa",
    clientName: "Rohan",
    stage: 4,
    status: "complete",
  },
  {
    propertyImage: "/properties/property2.png",
    propertyName: "Urban Apartment",
    clientName: "Yash",
    stage: 5,
    status: "pending",
  },
  {
    propertyImage: "/properties/property3.png",
    propertyName: "Cozy Cottage",
    clientName: "Rudra",
    stage: 3,
    status: "complete",
  },
  {
    propertyImage: "/properties/property1.png",
    propertyName: "Modern Condo",
    clientName: "Sony",
    stage: 2,
    status: "pending",
  },
  {
    propertyImage: "/properties/property1.png",
    propertyName: "Beach House",
    clientName: "Pinky",
    stage: 5,
    status: "complete",
  },
  {
    propertyImage: "/properties/property1.png",
    propertyName: "Beach House",
    clientName: "Pinky",
    stage: 5,
    status: "complete",
  },
  {
    propertyImage: "/properties/property1.png",
    propertyName: "Beach House",
    clientName: "Pinky",
    stage: 5,
    status: "complete",
  },
];

const DealTable = () => {
  const [propertyType, setPropertyType] = useState("");
  const [scoreRange, setScoreRange] = useState("");
  const [sortBy, setSortBy] = useState("");
  const router = useRouter();

  return (
    <div className="p-4 bg-white rounded-lg max-w-md mx-auto mt-2">
      <div className="fixed top-0 left-0 right-0 bg-white p-4 shadow-md flex items-center justify-between z-10">
        <IoArrowBack
          className="text-xl cursor-pointer"
          onClick={() => router.push("/broker")}
        />
        <h2 className="text-lg font-bold text-center flex-1">DEALS</h2>
      </div>
      <div className="mt-16">
        <table className="w-full table-fixed border-collapse text-sm flex flex-col gap-4">
          <thead className="bg-gray-100 text-left sticky top-12 z-10">
            <tr className="border-2">
              <th className="p-2 w-1/4">
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value)}
                  className="w-full p-1 text-sm border rounded"
                >
                  <option value="">Property</option>
                  <option value="house">House</option>
                  <option value="apartment">Apartment</option>
                  <option value="plot">Plot</option>
                  <option value="villa">Villa</option>
                </select>
              </th>
              <th className="p-2 w-1/4">
                <select
                  value={scoreRange}
                  onChange={(e) => setScoreRange(e.target.value)}
                  className="w-full p-1 text-sm border rounded"
                >
                  <option value="">Client</option>
                  <option value="1-5">1-5</option>
                  <option value="5-10">5-10</option>
                  <option value="10-15">10-15</option>
                  <option value="15-20">15-20</option>
                </select>
              </th>
              <th className="p-2 w-1/4">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full p-1 text-sm border rounded"
                >
                  <option value="">Stage</option>
                  <option value="price">Price</option>
                  <option value="location">Location</option>
                  <option value="size">Size</option>
                </select>
              </th>
              <th className="p-2 w-1/4 text-center">Status</th>
            </tr>
          </thead>

          <tbody className="mt-1 mb-16">
            {deals.map((deal, index) => (
              <tr key={index} className="border-b text-center">
                <td className="p-1 w-1/4">
                  <div className="flex flex-col items-center gap-1">
                    <Image
                      src={deal.propertyImage}
                      alt={deal.propertyName}
                      width={80}
                      height={70}
                      className="rounded-md"
                    />
                    <span className="text-[13px] font-medium">
                      {deal.propertyName}
                    </span>
                  </div>
                </td>
                <td className="p-2 w-1/4">{deal.clientName}</td>
                <td className="p-2 w-1/4">
                  {Array.from({ length: deal.stage }).map((_, i) => (
                    <span key={i} className="text-black text-xl">
                      ★
                    </span>
                  ))}
                </td>
                <td className="p-2 w-1/4">
                  <Badge status={deal.status}>
                    {deal.status.charAt(0).toUpperCase() + deal.status.slice(1)}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DealTable;
