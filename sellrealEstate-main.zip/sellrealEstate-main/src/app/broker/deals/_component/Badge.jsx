const Badge = ({ children, status }) => {
  const baseStyle = "px-2 py-1 rounded-full text-xs font-semibold text-white";
  const statusStyle = status === "complete" ? "bg-green-500" : "bg-red-500";

  return <span className={baseStyle + " " + statusStyle}>{children}</span>;
};

export default Badge;