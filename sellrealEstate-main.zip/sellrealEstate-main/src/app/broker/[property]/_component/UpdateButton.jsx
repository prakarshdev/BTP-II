"use client";

import React, { useState } from "react";
import toast, { Toaster } from "react-hot-toast";

const UpdateButton = ({ propertyId, builderConnectionStatus, soldStatus }) => {
  console.log("printng property id", propertyId);
  console.log("printng connection status", builderConnectionStatus);
  console.log("printng sold status", soldStatus);

  const [isSold, setIsSold] = useState(soldStatus);
  const [loading, setLoading] = useState(false);

  const handleMarkAsSold = async () => {
    if (builderConnectionStatus !== "accepted") {
      toast.error("First connect with builder");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/sold-status", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: propertyId }),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success("Property marked as sold");
        setIsSold(true);
      } else {
        toast.error(data.message || "Something went wrong");
      }
    } catch (error) {
      toast.error("Network error");
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={`text-white px-4 py-1 rounded-xl w-[150px] flex justify-center 
        ${isSold ? "bg-green-400" : "bg-black"}`}
    >
      <button
        onClick={handleMarkAsSold}
        disabled={isSold}
        className={`font-bold w-full ${
          isSold ? "text-gray-400 cursor-not-allowe" : ""
        }`}
      >
        {isSold ? "Solded" : loading ? "Updating..." : "Mark as Sold"}
      </button>
      <Toaster position="top-right" />
    </div>
  );
};

export default UpdateButton;
