"use client";
import React, { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ChevronLeft, ChevronRight } from "lucide-react";
import toast, { Toaster } from "react-hot-toast";
import UpdateButton from "./_component/UpdateButton";
import { marked } from "marked";

const BrokerPropertyPage = () => {
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [isBuilderExpanded, setIsBuilderExpanded] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [propertyData, setPropertyData] = useState(null);
  const [builderId, setBuilderId] = useState(null);
  const [builderData, setBuilderData] = useState(null);
  const [properyDescription, setPropertyDescription] = useState(null);
  const [builderDescription, setbuilderDescription] = useState(null);
  const [brokerId, setBrokerId] = useState(null);
  const [status, setStatus] = useState("");
  const router = useRouter();

  const [loading, setLoading] = useState(false);

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === propertyData?.mediaFiles.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? propertyData?.mediaFiles.length - 1 : prevIndex - 1
    );
  };

  const connectWithBuilder = async () => {
    if (propertyData?.soldStatus) {
      toast.error("property already solded you cannot connect");
      return;
    }
    const brokerToken = localStorage.getItem("brokerToken");
    if (!brokerToken) {
      toast.error("Please login first");
    } else {
      // authorization
      try {
        const response = await fetch("/api/auth/broker-logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${brokerToken}`,
          },
        });
        if (!response.ok) {
          toast.error("broker is not authorized");
          return;
        }
        const data = await response.json();
        const brokerId = data.brokerDetails._id;

        try {
          const response = await fetch("/api/connection-requests", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ brokerId, builderId, propertyId }),
          });
          if (response.ok) {
            const data = await response.json();
            toast.success(data.message);
          }
        } catch (error) {
          console.error("error in connect with builder api", error);
        }
      } catch (error) {
        console.log("error in broker authentication", error);
        toast.error("something went wrong");
      }
    }
  };

  function escapeHtml(text) {
    return text
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function generatePropertyDescription(propertyData) {
    return escapeHtml(`${propertyData.projectName} - ${
      propertyData.configuration
    } BHK, ${propertyData.address}

    ${propertyData.floorDetails} semi-furnished apartment with ${
      propertyData.numberOfBathrooms
    } baths, ${propertyData.numberOfBalconies} balcony, and parking. ${
      propertyData.projectStatus
    }, possession by ${new Date(
      propertyData.possessionDate
    ).toLocaleDateString()}.

    Prime location near ${propertyData.nearbyLandmarks} with ${
      propertyData.transportAccessibilityScore
    } connectivity.

    [View Report](${propertyData.aiGeneratedCatalogue})`);
  }

  function generateBuilderDescription(builderData) {
    return escapeHtml(`${builderData.name}, a leading ${builderData.propertyType} developer in ${builderData.location}, is **RERA-approved (${builderData.reraNumber})**, ensuring quality and transparency.

 Contact: ${builderData.contact}`);
  }

  var propertyId = useParams();
  propertyId = propertyId.property;

  // api call for the property of given id
  useEffect(() => {
    if (!propertyId) {
      return;
    }
    const fetchPropertyData = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/getproperty/${propertyId}`);
        if (response.ok) {
          const data = await response.json();
          const propertyData = data.property;
          setPropertyData(propertyData);
          const builderId = propertyData.builderId;
          setBuilderId(builderId);
          setLoading(false);
        }
      } catch (error) {
        console.error("error in getting property details", error);
        setLoading(false);
      } finally {
        setLoading(false);
      }
    };
    fetchPropertyData();
  }, [propertyId]);

  // getting builder details of the particular property
  useEffect(() => {
    if (!builderId) {
      return;
    }
    const fetchBuilderData = async () => {
      try {
        const response = await fetch(`/api/getbuilders/${builderId}`);
        if (response.ok) {
          const data = await response.json();
          const builderData = data.builder;
          setBuilderData(builderData);
        }
      } catch (error) {
        console.log("error in getting builderData", error);
        toast.error("error in getting builderData");
      }
    };
    fetchBuilderData();
  }, [builderId]);

  // broker connected or not logic
  useEffect(() => {
    const brokerToken = localStorage.getItem("brokerToken");
    if (!brokerToken) {
      return;
    }
    const getAuthorizedBrokerId = async () => {
      try {
        const response = await fetch("/api/auth/broker-logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${brokerToken}`,
          },
        });
        if (!response.ok) {
          toast.error("broker is not authorized");
          return;
        }
        const data = await response.json();
        const brokerId = data.brokerDetails._id;
        setBrokerId(brokerId);
      } catch (error) {
        toast.error("broker authentication in connction logit failed");
        console.error("broker authentication in connction logit failed", error);
      }
    };
    getAuthorizedBrokerId();
  }, []);
  useEffect(() => {
    if (!brokerId || !builderId || !propertyId) {
      return;
    }
    const isConnected = async () => {
      try {
        const response = await fetch(
          `/api/check-request?brokerId=${brokerId}&builderId=${builderId}&propertyId=${propertyId}`
        );
        if (!response.ok) {
          console.error("not getting response");
        }
        const data = await response.json();
        if (data?.request?.status) {
          setStatus(data.request.status);
        } else {
          console.log("No connection request found");
        }
      } catch (error) {
        console.error("error in checkint connection");
      }
    };
    isConnected();
  }, [brokerId, builderId, propertyId]);

  // generating propertyData description
  useEffect(() => {
    if (!propertyData) {
      return;
    }
    const description = generatePropertyDescription(propertyData);
    setPropertyDescription(description);
  }, [propertyData]);

  // generating builderData description
  useEffect(() => {
    if (!builderData) {
      return;
    }
    const description = generateBuilderDescription(builderData);
    setbuilderDescription(description);
  }, [builderData]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="w-8 h-8 border-4 border-gray-200 border-t-gray-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden pb-16">
      {/* Upper part - Carousel */}
      <div className="relative h-[35vh]">
        <div
          className="flex justify-between bg-cover bg-center h-full w-full transition-opacity duration-500"
          style={{
            backgroundImage: `url(${propertyData?.mediaFiles[currentImageIndex]})`,
          }}
        >
          <ChevronLeft
            className="text-white w-8 h-8 mt-4 ml-4 relative z-10 cursor-pointer"
            onClick={() => router.back()}
          />
        </div>

        {/* Carousel navigation */}
        <div className="absolute inset-0 flex items-center justify-between p-4">
          <button
            onClick={prevImage}
            className="bg-black/50 text-white rounded-full p-1 hover:bg-black/70 transition-all"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextImage}
            className="bg-black/50 text-white rounded-full p-1 hover:bg-black/70 transition-all"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Lower part */}
      <div className="flex-1 flex flex-col justify-between p-4 overflow-y-auto">
        <div className="flex-1 flex flex-col">
          <div className="flex justify-between">
            <span className="bg-green-100 text-black text-base font-medium me-2 px-2.5 py-2 rounded-sm">
              Brokerage {propertyData?.brokerage}%
            </span>
            <UpdateButton
              propertyId={propertyId}
              builderConnectionStatus={status}
              soldStatus={propertyData?.soldStatus}
            />
          </div>
          <div className="mt-2">
            <h1 className="text-lg font-bold">{propertyData?.projectName}</h1>
            <div className="relative">
              <p
                className={`text-sm text-gray-700 ${
                  !isDescriptionExpanded ? "line-clamp-2" : ""
                }`}
              >
                {properyDescription}
              </p>

              <button
                onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
                className="text-blue-600 text-sm font-medium hover:text-blue-800 mt-1"
              >
                {isDescriptionExpanded ? "See Less" : "See More"}
              </button>
            </div>
          </div>
          <div className="flex-1 flex flex-col mt-3">
            <h1 className="text-xl font-semibold">Builder details</h1>
            <div className="grid grid-cols-3 gap-4 mt-2">
              <div className="col-span-1">
                <img
                  src={builderData?.builderImage}
                  alt="builder"
                  className="max-h-24 object-contain"
                />
              </div>
              <div className="col-span-2 flex flex-col gap-2">
                <h1 className="text-lg font-semibold">{builderData?.name}</h1>
                <div className="relative">
                  <p
                    className={`text-sm text-gray-700 ${
                      !isBuilderExpanded ? "line-clamp-2" : ""
                    }`}
                  >
                    {builderDescription}
                  </p>
                  <button
                    onClick={() => setIsBuilderExpanded(!isBuilderExpanded)}
                    className="text-blue-600 text-sm font-medium hover:text-blue-800 mt-1"
                  >
                    {isBuilderExpanded ? "See Less" : "See More"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-auto pt-2">
          {/* <button
            onClick={connectWithBuilder}
            className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-md w-full"
          >
            Connect with builder
          </button> */}
          {status === "accepted" ? (
            <button
              disabled
              className="bg-green-600 text-white text-center text-md font-bold px-4 py-2 rounded-md w-full cursor-not-allowed"
            >
              Connected
            </button>
          ) : (
            <button
              onClick={connectWithBuilder}
              className="bg-black text-white text-center text-md font-bold px-4 py-2 rounded-md w-full"
            >
              Connect with builder
            </button>
          )}
        </div>
      </div>

      {/* Toaster component */}
      <Toaster position="top-right" />
    </div>
  );
};

export default BrokerPropertyPage;
