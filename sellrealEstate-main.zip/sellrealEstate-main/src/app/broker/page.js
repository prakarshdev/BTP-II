"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Card from "./_component/Card";
import Header from "./_component/Header";
import SearchBar from "./_component/SearchBar";
import propertyData from "../../lib/propertyData";
import InquiryForm from "./_component/InquiryForm";
import useFilterStore from "../../store/useFilterStore";

const BrokerPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showInquiryForm, setShowInquiryForm] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [properties, setProperties] = useState([]);

  const {
    priceRange,
    selectedType,
    setPriceRange,
    setSelectedType,
    resetFilters,
  } = useFilterStore();

  // Fetch properties data
  useEffect(() => {
    const fetchProperties = async () => {
      try {
        const response = await fetch("/api/getproperty");
        if (!response.ok) {
          throw new Error("Failed to fetch properties");
        }
        const data = await response.json();
        const propertyData = data.properties;
        setProperties(propertyData);
      } catch (error) {
        console.error("Error fetching properties:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProperties();
  }, []);

  // Function to filter properties based on search query, price range, and selected type
  let filteredProperties = properties.filter((property) => {
    const queryMatch =
      !searchQuery ||
      property?.projectName
        ?.toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      property?.features?.some((feature) =>
        feature?.toLowerCase().includes(searchQuery.toLowerCase())
      ) ||
      property?.description?.toLowerCase().includes(searchQuery.toLowerCase());

    const priceMatch =
      property?.price >= priceRange[0] && property?.price <= priceRange[1];

    const typeMatch = !selectedType || property?.type === selectedType;

    return queryMatch && priceMatch && typeMatch;
  });

  // Function to update search query
  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  // Function to toggle the inquiry form
  const toggleInquiryForm = () => {
    setShowInquiryForm(!showInquiryForm);
  };

  return (
    <div className="min-h-screen flex flex-col gap-4">
      {/* Fixed header with search bar */}
      <div className="fixed z-10 bg-white gap-2 flex flex-col w-full">
        <Header />
        <SearchBar onSearch={handleSearch} />
      </div>

      {/* Property listing */}
      <div className="mt-32">
        {isLoading ? (
          <div className="text-center p-10">
            <p className="text-gray-500">Loading properties...</p>
          </div>
        ) : filteredProperties.length > 0 ? (
          filteredProperties.map((property) => (
            <Link key={property._id} href={`/broker/${property._id}`} passHref>
              <Card
                key={property._id}
                id={property._id}
                property={property?.projectName}
                typeOfProperty={property?.typeOfProperty}
                configuration={property?.configuration}
                price={property?.price}
                brokerage={property?.brokerage}
                address={property?.address}
                projectStatus={property?.projectStatus}
                mediaFiles={property?.mediaFiles}
                builtUpArea={property?.builtUpArea}
                furnishingStatus={property?.furnishingStatus}
              />
            </Link>
          ))
        ) : (
          <div className="text-center p-10">
            <p className="text-gray-500">
              No properties found matching {searchQuery}
            </p>
          </div>
        )}

        {/* Inquiry Form Button */}
        <div className="flex justify-end mb-20 mx-5 mt-8">
          <button
            onClick={toggleInquiryForm}
            className="bg-black text-white px-6 py-2 rounded-lg shadow-lg hover:bg-gray-800 transition-colors w-full"
          >
            {showInquiryForm ? "Close Inquiry" : "Make Inquiry"}
          </button>
        </div>
      </div>

      {/* Inquiry Form Modal */}
      {showInquiryForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="p-4">
              <button
                onClick={toggleInquiryForm}
                className="ml-auto block text-gray-500 hover:text-gray-700"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
              <InquiryForm />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BrokerPage;
