"use client";

import React, { useState, useEffect } from "react";
import { MdHome } from "react-icons/md";
import { FaHandshake } from "react-icons/fa6";
import { FaUser } from "react-icons/fa";
import { useRouter, usePathname } from "next/navigation";

const Footer = () => {
  const [selected, setSelected] = useState("home");
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (pathname === "/broker") {
      setSelected("home");
    } else if (pathname === "/broker/deals") {
      setSelected("deals");
    } else if (pathname === "/broker/clients") {
      setSelected("clients");
    }
  }, [pathname]);

  const handleClick = (section) => {
    setSelected(section);
    if (section === "home") {
      router.push("/broker");
    } else if (section === "deals") {
      router.push("/broker/deals");
    } else if (section === "clients") {
      router.push("/broker/clients");
    }
  };

  return (
    <div className="flex justify-between items-center fixed bottom-0 left-0 w-full bg-white px-12 border-t border-gray-200">
      <div
        className={`flex flex-col items-center gap-0.5 cursor-pointer rounded-lg p-2 ${
          selected === "home" ? "bg-green-100" : ""
        }`}
        onClick={() => handleClick("home")}
      >
        <MdHome className="text-2xl" />
        <p>Home</p>
      </div>
      <div
        className={`flex flex-col items-center gap-0.5 cursor-pointer rounded-lg p-2 ${
          selected === "deals" ? "bg-green-100" : ""
        }`}
        onClick={() => handleClick("deals")}
      >
        <FaHandshake className="text-2xl" />
        <p>Deals</p>
      </div>
      <div
        className={`flex flex-col items-center gap-0.5 cursor-pointer rounded-lg p-2 ${
          selected === "clients" ? "bg-green-100" : ""
        }`}
        onClick={() => handleClick("clients")}
      >
        <FaUser className="text-2xl" />
        <p>Clients</p>
      </div>
    </div>
  );
};

export default Footer;
