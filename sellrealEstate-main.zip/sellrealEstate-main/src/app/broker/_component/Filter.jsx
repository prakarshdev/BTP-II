"use client";

import { useRef, useEffect, useState } from "react";
import useFilterStore from "../../../store/useFilterStore";

export default function FilterModal({ onClose }) {
  const modalRef = useRef(null);
  const propertyTypes = ["House", "Apartment", "Plot", "Villa"];

  //zustand store selectors
  const {
    priceRange,
    selectedType,
    setPriceRange,
    setSelectedType,
    resetFilters,
  } = useFilterStore();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [onClose]);

  // Handle slider change
  const handleSliderChange = (index, value) => {
    const newRange = [...priceRange];
    newRange[index] = Number(value);
    setPriceRange(newRange);
  };

  return (
    <div className="fixed inset-0 backdrop-blur-[2px] bg-black/1.5 z-40">
      <div
        ref={modalRef}
        className="fixed bottom-0 left-0 w-full bg-white pt-3 px-6 pb-6 rounded-t-3xl shadow-lg min-h-fit max-h-[90vh] overflow-y-auto z-50"
      >
        <div className="w-16 h-1 bg-gray-400 rounded-full mx-auto mb-4"></div>
        <h2 className="text-2xl font-bold mb-4">Select filters</h2>

        {/* Price Range */}
        <div className="mb-6">
          <p className="text-xl font-medium mb-2">Price range</p>
          <div className="relative w-full h-1">
            <div className="absolute w-full h-1 bg-gray-200 rounded"></div>
            <div
              className="absolute h-1 bg-gray-600 rounded"
              style={{
                left: `${
                  ((priceRange[0] - 100000) / (100000000 - 100000)) * 100
                }%`,
                right: `${
                  100 - ((priceRange[1] - 100000) / (100000000 - 100000)) * 100
                }%`,
              }}
            ></div>
            <input
              type="range"
              min="100000"
              max="100000000"
              step="100000"
              value={priceRange[0]}
              onChange={(e) => {
                const value = Math.min(
                  Number(e.target.value),
                  priceRange[1] - 100000
                );
                handleSliderChange(0, value);
              }}
              className="absolute w-full h-1 appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-gray-600 [&::-webkit-slider-thumb]:appearance-none [&::-moz-range-thumb]:pointer-events-auto [&::-moz-range-thumb]:w-6 [&::-moz-range-thumb]:h-6 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-gray-600 [&::-moz-range-thumb]:border-0"
            />
            <input
              type="range"
              min="100000"
              max="100000000"
              step="100000"
              value={priceRange[1]}
              onChange={(e) => {
                const value = Math.max(
                  Number(e.target.value),
                  priceRange[0] + 100000
                );
                handleSliderChange(1, value);
              }}
              className="absolute w-full h-1 appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-gray-600 [&::-webkit-slider-thumb]:appearance-none [&::-moz-range-thumb]:pointer-events-auto [&::-moz-range-thumb]:w-6 [&::-moz-range-thumb]:h-6 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-gray-600 [&::-moz-range-thumb]:border-0"
            />
          </div>
          <p className="text-right text-sm font-medium mt-4">
            Rs. {priceRange[0].toLocaleString()} -{" "}
            {priceRange[1].toLocaleString()}
          </p>
        </div>

        {/* Property Type Selection */}
        <div className="mb-6">
          <p className="text-base font-medium mb-2">Property type</p>
          <div className="grid grid-cols-2 gap-3">
            {propertyTypes.map((type) => (
              <button
                key={type}
                className={`w-full p-2 rounded-lg text-base font-medium border transition flex flex-col items-center  gap-0.5 ${
                  selectedType === type
                    ? "bg-green-500 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() =>
                  setSelectedType(selectedType === type ? null : type)
                }
              >
                <img
                  src={`/assets/icons/${type.toLowerCase()}.png`}
                  alt={type}
                  className="w-6 h-6"
                />
                <p className="text-sm font-medium">{type}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Apply Button */}
        <div className="flex gap-3">
          <button
            className="w-1/4 p-2 bg-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-300 transition"
            onClick={() => {
              setPriceRange([100000, 100000000]);
              setSelectedType(null);
            }}
          >
            Reset
          </button>
          <button
            className="w-3/4 p-2 bg-black text-white font-medium rounded-lg hover:bg-gray-800 transition"
            onClick={() => {
              onClose();
            }}
          >
            Apply
          </button>
        </div>
      </div>
    </div>
  );
}
