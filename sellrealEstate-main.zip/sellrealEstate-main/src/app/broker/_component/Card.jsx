"use client";

import React from "react";
import { useRouter } from "next/navigation";

const Card = ({
  id,
  property = "Unnamed Project",
  typeOfProperty = "Apartment",
  configuration = "3",
  price = 500000,
  brokerage = 1,
  address = "Address not available",
  mediaFiles = [],
  projectStatus = "Status not available",
  furnishingStatus = "furnished",
}) => {
  const router = useRouter();

  // Format price with commas
  const formattedPrice =
    typeof price === "number" ? price.toLocaleString() : "0";

  return (
    <div
      className="flex flex-col gap-2 p-4 rounded-lg bg-white cursor-pointer hover:shadow-lg transition-shadow"
      onClick={() => router.push(`/broker/${property}`)}
    >
      <div className="rounded-2xl overflow-hidden h-[200px] relative">
        <img
          src={mediaFiles?.[0] || "/properties/property1.png"}
          alt={property}
          className="object-cover h-full w-full"
        />
      </div>
      <div className="space-y-1">
        <div className="flex justify-between items-start">
          <h1 className="text-xl font-bold">{property}</h1>
          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm">
            {projectStatus}
          </span>
        </div>

        <div className="flex items-center gap-2 text-gray-600">
          <span>{typeOfProperty}</span>
          <span>•</span>
          <span>{configuration} BHK</span>
          <span>•</span>
          <span>{furnishingStatus}</span>
        </div>

        <div className="text-lg font-semibold text-gray-800">
          ₹{formattedPrice}
        </div>

        <div className="flex items-center gap-1 text-sm text-gray-500">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
            />
          </svg>
          <span>{address}</span>
        </div>
      </div>
    </div>
  );
};

export default Card;
