"use client";

import { useState } from "react";
import SearchingProperty from "./SearchingProperty";
import BrokerageRate from "./BrokerageRate";
import toast, { Toaster } from "react-hot-toast";

export default function InquiryForm() {
  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    location: "",
    area: "",
    searching: [],
    brokerage: "",
    question: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.name ||
      !formData.contact ||
      !formData.location ||
      !formData.area ||
      !formData.searching.length ||
      !formData.brokerage
    ) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      const response = await fetch("/api/inquiry", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          contact: formData.contact,
          area: formData.area,
          brokerage: formData.brokerage,
          searching: formData.searching || [],
        }),
      });
      if (response.ok) {
        console.log("Inquiry created successfully");
        toast.success("Inquiry created successfully");
        // Reset form
        setFormData({
          name: "",
          contact: "",
          location: "",
          area: "",
          searching: [],
          brokerage: "",
          question: "",
        });
      } else {
        const error = await response.json();
        console.log("Error creating inquiry:", error);
        toast.error(error.message || "Error creating inquiry");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      toast.error("Error submitting form");
    }
  };

  const handleSearching = (data) => {
    setFormData({ ...formData, searching: data });
  };

  const handleBrokerage = (data) => {
    setFormData({ ...formData, brokerage: data });
  };

  return (
    <div className="max-w-md mx-auto px-4 bg-white rounded-lg">
      {/* <div className="bg-black w-full h-0.5 rounded-lg"></div> */}
      <h2 className="text-2xl text-center font-bold text-gray-800 mb-3 mt-3 underline">
        Inquiry Form
      </h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="text-base font-semibold">
            Name
          </label>
          <input
            type="text"
            name="name"
            id="name"
            value={formData.name}
            onChange={handleChange}
            className="h-10 bg-gray-100 rounded-md px-3 py-2 w-full"
            placeholder="Enter your name"
            required
          />
        </div>
        <div>
          <label htmlFor="contact" className="text-base font-semibold">
            Contact
          </label>
          <input
            type="number"
            name="contact"
            id="contact"
            value={formData.contact}
            onChange={handleChange}
            className="h-10 bg-gray-100 rounded-md px-3 py-2 w-full"
            placeholder="Enter your contact"
            required
          />
        </div>
        <div>
          <label htmlFor="location" className="text-base font-semibold">
            Location (search by city)
          </label>
          <input
            type="text"
            name="location"
            id="location"
            value={formData.location}
            onChange={handleChange}
            className="h-10 bg-gray-100 rounded-md px-3 py-2 w-full"
            placeholder="Enter city name"
            required
          />
        </div>
        <div>
          <label htmlFor="area" className="text-base font-semibold">
            Area (full address)
          </label>
          <input
            type="text"
            name="area"
            id="area"
            value={formData.area}
            onChange={handleChange}
            className="h-10 bg-gray-100 rounded-md px-3 py-2 w-full"
            placeholder="Enter full address"
            required
          />
        </div>
        <SearchingProperty sendDataToParent={handleSearching} />
        <BrokerageRate sendDataToParent={handleBrokerage} />
        <div>
          <label htmlFor="question" className="text-base font-semibold">
            Any Questions?
          </label>
          <textarea
            name="question"
            id="question"
            value={formData.question}
            onChange={handleChange}
            className="h-20 bg-gray-100 rounded-md px-3 py-2 w-full"
            placeholder="Enter your question"
          ></textarea>
        </div>
        <button
          type="submit"
          className="w-full bg-black text-white p-2 rounded-md"
        >
          Submit
        </button>
      </form>
      <Toaster
        position="top-right"
        toastOptions={{
          success: {
            duration: 3000,
            iconTheme: {
              primary: "green",
              secondary: "black",
            },
          },
        }}
      />
    </div>
  );
}