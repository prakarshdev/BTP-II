"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

export default function BrokerageRate({ sendDataToParent }) {
  const [showOptions, setShowOptions] = useState(false);
  const [selectedOption, setSelectedOption] = useState("");

  const options = [
    "1% - 2%",
    "2% - 3%",
    "3% - 4%",
    "4% - 5%",
    "5% - 6%",
    "6% - 7%",
    "7% - 8%",
    "8% - 9%",
    "9% - 10%",
  ];

  const handleSelect = (option) => {
    setSelectedOption(option);
    sendDataToParent(option);
    setShowOptions(false);
  };

  return (
    <div className="flex flex-col gap-1 w-full">
      <label htmlFor="dropdown" className="text-base font-semibold">
        Brokerage Rate
      </label>
      <div className="relative">
        <div
          className="flex items-center justify-between min-h-[40px] bg-gray-100 rounded-md px-3 py-2 w-full cursor-pointer"
          onClick={() => setShowOptions(!showOptions)}
        >
          <span className={selectedOption ? "text-black" : "text-gray-500"}>
            {selectedOption || "Select brokerage rate"}
          </span>
          <button type="button">
            {showOptions ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
        </div>
        {showOptions && (
          <ul className="absolute left-0 right-0 bg-gray-100 rounded-lg shadow-md max-h-[200px] overflow-y-auto z-10">
            {options.map((option, index) => (
              <li
                key={index}
                onClick={() => handleSelect(option)}
                className={`p-2 hover:bg-gray-200 cursor-pointer ${
                  selectedOption === option ? "bg-blue-50" : ""
                }`}
              >
                {option}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
