"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp, X } from "lucide-react";

export default function SearchingProperty({ sendDataToParent }) {
  const [showOptions, setShowOptions] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState([]);

  const options = ["House", "Apartment", "Plot", "Villa"];

  const handleSelect = (option) => {
    if (selectedOptions.includes(option)) {
      const newOptions = selectedOptions.filter((item) => item !== option);
      setSelectedOptions(newOptions);
      sendDataToParent(newOptions);
    } else {
      const newOptions = [...selectedOptions, option];
      setSelectedOptions(newOptions);
      sendDataToParent(newOptions);
    }
  };

  const removeOption = (option) => {
    const newOptions = selectedOptions.filter((item) => item !== option);
    setSelectedOptions(newOptions);
    sendDataToParent(newOptions);
  };

  return (
    <div className="flex flex-col gap-1 w-full">
      <label htmlFor="dropdown" className="text-base font-semibold">
        Searching Property Type
      </label>
      <div className="relative">
        <div
          className="flex flex-wrap items-center min-h-[40px] bg-gray-100 rounded-md px-3 py-2 w-full cursor-pointer"
          onClick={() => setShowOptions(!showOptions)}
        >
          <div className="flex flex-wrap gap-1 flex-1">
            {selectedOptions.length === 0 ? (
              <span className="text-gray-500">Select property types</span>
            ) : (
              selectedOptions.map((option, index) => (
                <span
                  key={index}
                  className="flex items-center gap-1 bg-blue-100 text-blue-800 px-2 py-1 rounded-md text-sm"
                >
                  {option}
                  <X
                    size={14}
                    className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeOption(option);
                    }}
                  />
                </span>
              ))
            )}
          </div>
          <button type="button">
            {showOptions ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
        </div>
        {showOptions && (
          <ul className="absolute left-0 right-0 bg-gray-100 rounded-lg shadow-md max-h-[200px] overflow-y-auto z-10">
            {options.map((option, index) => (
              <li
                key={index}
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelect(option);
                }}
                className={`p-2 hover:bg-gray-200 cursor-pointer ${
                  selectedOptions.includes(option) ? "bg-blue-50" : ""
                }`}
              >
                {option}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
