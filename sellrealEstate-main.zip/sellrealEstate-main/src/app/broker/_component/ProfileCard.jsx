"use client";

import React, { useEffect, useState } from "react";
import { X, LogOut, Edit } from "lucide-react";
import { useRouter } from "next/navigation";
import toast, { Toaster } from "react-hot-toast";

const ProfileCard = ({ onClose }) => {
  const [brokerToken, setBrokerToken] = useState(null);
  const [brokerInfo, setBrokerInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  const router = useRouter();

  useEffect(() => {
    const brokerToken = localStorage.getItem("brokerToken");
    if (!brokerToken) {
      router.push("/log-in");
      return;
    }
    setBrokerToken(brokerToken);
    const fetchbrokerProfileData = async () => {
      try {
        const response = await fetch("/api/auth/broker-logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${brokerToken}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setBrokerInfo(data.brokerDetails);
          setLoading(false);
        } else {
          console.error("getting error in brokerInfo");
        }
      } catch (error) {
        console.log("error in logout api", error);
      }
    };
    fetchbrokerProfileData();
  }, [brokerToken]);

  // handle logout button
  const handleLogout = () => {
    const brokerToken = localStorage.getItem("brokerToken");
    if (!brokerToken) {
      return;
    }
    localStorage.removeItem("brokerToken");
    localStorage.removeItem("brokerId");
    toast.success("broker logged out successfully");
    router.push("/log-in");
  };

  const handleEditProfile = () => {
    router.push("/edit-profile");
  };

  if (loading) {
    return (
      <div>
        <div className="w-8 h-8 border-4 border-gray-200 border-t-gray-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="fixed top-0 right-0 bg-white text-black shadow-2xl rounded-2xl p-6 w-[250px] max-w-xs mx-auto border border-gray-200">
      {/* Close Button */}
      <button
        className="absolute top-3 right-3 text-gray-500 hover:text-black"
        onClick={onClose}
      >
        <X className="w-6 h-6" />
      </button>

      {/* Profile Picture */}
      <div className="flex flex-col items-center relative">
        <button
          onClick={handleEditProfile}
          className="absolute top-0 left-0 bg-gray-200 p-1 rounded-full hover:bg-gray-300"
        >
          <Edit className="w-5 h-5 text-gray-700" />
        </button>
        <img
          src={brokerInfo?.profilePicture}
          alt="Profile Picture"
          width={80}
          height={80}
          className="rounded-full border-4 border-gray-300 shadow-sm"
        />
      </div>

      <h2 className="text-lg font-bold mt-3 text-center text-gray-900">
        {brokerInfo?.fullName}
      </h2>
      <p className="text-sm text-gray-500 text-center">
        {brokerInfo?.companyName}
      </p>

      {/* User Details */}
      <div className="mt-4 text-sm space-y-3 text-center">
        <p>
          <span className="text-gray-500 font-medium">Phone:</span>{" "}
          {brokerInfo?.phoneNumber}
        </p>
        <p>
          <span className="text-gray-500 font-medium">Experience:</span>{" "}
          {brokerInfo?.yearOfExperience} yrs
        </p>
        <p>
          <span className="text-gray-500 font-medium">RERA No.:</span>{" "}
          {brokerInfo?.reraRegistrationNumber}
        </p>
        <p>
          <span className="text-gray-500 font-medium">Sold Properties:</span>{" "}
          {brokerInfo?.totalPropertiesSold}
        </p>
        <p>
          <span className="text-gray-500 font-medium">Closed Deals:</span>{" "}
          {brokerInfo?.pastDealClosures}
        </p>
        <p>
          <span className="text-gray-500 font-medium">Brokerage Fee:</span>{" "}
          {brokerInfo?.brokerageFeeStructure}
        </p>
      </div>

      {/* Logout Button */}
      <button
        onClick={handleLogout}
        className="mt-6 flex items-center justify-center gap-2 w-full bg-gray-900 hover:bg-gray-700 text-white py-2 rounded-lg transition font-medium"
      >
        <LogOut className="w-5 h-5" /> Logout
      </button>
      <Toaster />
    </div>
  );
};

export default ProfileCard;
