"use client";

import React, { useState, useRef, useEffect } from "react";
import { FaUserCircle } from "react-icons/fa";
import ProfileCard from "./ProfileCard";

const Header = () => {
  const [showProfileCard, setShowProfileCard] = useState(false);
  const profileRef = useRef(null);

  // Handle outside clicks
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setShowProfileCard(false);
      }
    };

    if (showProfileCard) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showProfileCard]);

  return (
    <div className="relative flex justify-between items-center px-5 pt-4 mr-1">
      <div>
        <img
          src="/assets/logo.png"
          alt="logo"
          className="w-10 h-9 object-cover"
        />
      </div>

      {/* User Icon to Toggle ProfileCard */}
      <div
        onClick={() => setShowProfileCard(!showProfileCard)}
        className="cursor-pointer"
      >
        <FaUserCircle className="text-4xl" />
      </div>

      {/* Profile Card */}
      {showProfileCard && (
        <div ref={profileRef} className="absolute top-12 right-5 z-20">
          <ProfileCard onClose={() => setShowProfileCard(false)} />
        </div>
      )}
    </div>
  );
};

export default Header;
