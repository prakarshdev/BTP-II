"use client";

import React, { useState } from "react";
import { IoMdSearch } from "react-icons/io";
import FilterModal from "./Filter";

const SearchBar = ({ onSearch }) => {
  const [showFilter, setShowFilter] = useState(false);
  const [searchText, setSearchText] = useState("");

  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchText(value);
    onSearch(value);
  };

  return (
    <div className="flex justify-between items-center px-5 py-2 gap-2">
      <div className="flex items-center gap-1 bg-gray-100 rounded-full px-4 py-2 w-full">
        <IoMdSearch className="text-2xl text-gray-400" />
        <input
          type="text"
          placeholder="Find properties"
          className="outline-none bg-transparent w-full"
          value={searchText}
          onChange={handleSearch}
        />
      </div>
      <div className="flex items-center border border-gray-300 rounded-2xl bg-white">
        <button className="px-3 py-2" onClick={() => setShowFilter(true)}>
          Filters
        </button>
      </div>
      {showFilter && <FilterModal onClose={() => setShowFilter(false)} />}
    </div>
  );
};

export default SearchBar;
