"use client";

import React, { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { useRouter } from "next/navigation";
import {
  FaBuilding,
  FaMapMarkerAlt,
  FaBriefcase,
  FaHome,
  FaBullhorn,
  FaAd,
} from "react-icons/fa";

const BrokerProfile = () => {
  const { id } = useParams(); // Get broker's id from URL
  const [broker, setBroker] = useState(null);
  const [loading, setLoading] = useState(true);

  const router = useRouter();

  useEffect(() => {
    if (!id) return;

    const fetchBroker = async () => {
      try {
        const res = await fetch(`/api/getbroker/${id}`);
        const data = await res.json();

        if (data.success) {
          setBroker(data.broker);
        } else {
          console.error("Broker not found:", data.message);
        }
      } catch (error) {
        console.error("Error fetching broker:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBroker();
  }, [id]);

  // authorization step
  const [builderToken, setBuilderToken] = useState(null);
  const [builderId, setBuilderId] = useState(null);
  useEffect(() => {
    const builderToken = localStorage.getItem("builderToken");
    if (!builderToken) {
      router.push("/log-in");
    }
    setBuilderToken(builderToken);
  }, []);

  useEffect(() => {
    if (!builderToken) {
      return;
    }
    const fetchBuilderData = async () => {
      try {
        const response = await fetch("/api/auth/builder-logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${builderToken}`,
          },
        });
        if (!response.ok) {
          console.log("builder is not authorized");
          router.push("/log-in");
        }
        const data = await response.json();
        const builderId = data.builderDetails._id;
        setBuilderId(builderId);
      } catch (error) {
        console.error("printing authorization error", error);
      }
    };
    fetchBuilderData();
  }, [builderToken]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading broker data...</p>
      </div>
    );
  }

  if (!broker) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Broker not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-gray-500 to-gray-600 p-6">
      <div className="w-full max-w-md p-6 bg-white shadow-xl rounded-lg text-center border border-gray-200">
        <img
          src={broker.profilePicture || "/assets/user.jpeg"}
          alt="Profile"
          className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-blue-400 shadow-md"
        />
        <h1 className="text-2xl font-bold text-gray-900">{broker.fullName}</h1>
        <p className="text-gray-600 flex items-center justify-center gap-2 mt-1">
          <FaBuilding /> {broker.companyName}
        </p>
        <p className="text-sm text-gray-500 flex items-center justify-center gap-2 mt-2">
          <FaMapMarkerAlt /> {broker.businessAddress}
        </p>
        <p className="text-sm text-gray-500 flex items-center justify-center gap-2 mt-2">
          {/* <FaMapMarkerAlt /> {broker.businessAddress} */}
          {broker.phoneNumber}
        </p>

        <div className="mt-4 text-left space-y-3">
          <div className="flex items-center gap-2 text-gray-700">
            <FaBriefcase className="text-blue-500" />
            <span className="font-medium">Experience:</span>{" "}
            {broker.yearOfExperience} years
          </div>
          <div className="flex items-center gap-2 text-gray-700">
            <FaHome className="text-green-500" />
            <span className="font-medium">Total Sold:</span>{" "}
            {broker.totalPropertiesSold}
          </div>
          <div className="flex items-center gap-2 text-gray-700">
            <FaBullhorn className="text-purple-500" />
            <span className="font-medium">RERA:</span>{" "}
            {broker.reraRegistrationNumber}
          </div>
        </div>

        <div className="mt-6 border-t border-gray-300 pt-4 text-sm text-left">
          <h2 className="font-semibold text-gray-800">
            Preferred Property Types
          </h2>
          <p className="text-gray-600">
            {broker.preferredPropertyType.join(", ")}
          </p>
        </div>
        <div className="mt-4 border-t border-gray-300 pt-4 text-sm text-left">
          <h2 className="font-semibold text-gray-800">Marketing Platforms</h2>
          <p className="text-gray-600">
            {broker.marketingPlatformUsed.join(", ")}
          </p>
        </div>
        <div className="mt-4 border-t border-gray-300 pt-4 text-sm text-left">
          <h2 className="font-semibold text-gray-800">Ads Platforms</h2>
          <p className="text-gray-600">{broker.adsPlatformUsed.join(", ")}</p>
        </div>
      </div>
    </div>
  );
};

export default BrokerProfile;
