"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Brokers() {
  const [brokers, setBrokers] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();

  useEffect(() => {
    fetch("/api/getbroker")
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setBrokers(data.brokers);
        } else {
          setError("Failed to fetch brokers");
        }
        setLoading(false);
      })
      .catch(() => {
        setError("Error fetching data");
        setLoading(false);
      });
  }, []);

  // authorization step
  const [builderToken, setBuilderToken] = useState(null);
  const [builderId, setBuilderId] = useState(null);
  useEffect(() => {
    const builderToken = localStorage.getItem("builderToken");
    if (!builderToken) {
      router.push("/log-in");
    }
    setBuilderToken(builderToken);
  }, []);

  useEffect(() => {
    if (!builderToken) {
      return;
    }
    const fetchBuilderData = async () => {
      try {
        const response = await fetch("/api/auth/builder-logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${builderToken}`,
          },
        });
        if (!response.ok) {
          console.log("builder is not authorized");
          router.push("/log-in");
        }
        const data = await response.json();
        const builderId = data.builderDetails._id;
        setBuilderId(builderId);
      } catch (error) {
        console.error("printing authorization error", error);
      }
    };
    fetchBuilderData();
  }, [builderToken]);

  const filteredBrokers = brokers.filter(
    (broker) =>
      (broker.cities &&
        broker.cities.some((city) =>
          city.toLowerCase().includes(search.toLowerCase())
        )) ||
      (broker.businessAddress &&
        broker.businessAddress.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="p-4 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold text-center mb-6">Brokers</h1>

      <div className="flex justify-center mb-6">
        <input
          type="text"
          placeholder="Search by City or Address..."
          className="border p-3 w-full max-w-md rounded-lg shadow-sm outline-none focus:ring-2 focus:ring-blue-500"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {loading && <p className="text-center">Loading...</p>}
      {error && <p className="text-center text-red-500">{error}</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {filteredBrokers.map((broker) => (
          <Link
            key={broker._id}
            href={`/broker-data/${broker._id}`}
            className="bg-white rounded-xl shadow-md p-4 flex items-center gap-4 hover:shadow-lg transition-all cursor-pointer"
          >
            <img
              src={
                broker.profilePicture?.startsWith("data:image")
                  ? broker.profilePicture
                  : broker.profilePicture || "/assets/user.jpeg"
              }
              alt={broker.fullName}
              className="w-16 h-16 rounded-full object-cover"
            />

            <div className="flex flex-col">
              <h2 className="text-lg font-semibold">{broker.fullName}</h2>
              <p className="text-gray-600">{broker.cities?.join(", ")}</p>
              <p className="mt-2 text-sm text-gray-500">
                <strong>Company:</strong> {broker.companyName}
              </p>
              <p className="text-sm text-gray-500">
                <strong>Phone:</strong> {broker.phoneNumber}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
